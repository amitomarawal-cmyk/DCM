SimplePhone - contacts, dialer, SMS, backup/restore.
BUILD (no PC): upload all files to a GitHub repo -> Actions tab -> "Build APK" -> download artifact SimplePhone-apk.
BUILD (PC): open this folder in Android Studio -> Build > Build APK(s).
