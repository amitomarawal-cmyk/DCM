Simple Phone - Creator: Mohammod Abdul Awal
Build: push to GitHub -> Actions tab -> Build APK -> Artifacts -> SimplePhone-APK
