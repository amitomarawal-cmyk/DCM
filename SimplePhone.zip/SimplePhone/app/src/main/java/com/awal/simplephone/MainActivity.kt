package com.awal.simplephone

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentProviderOperation
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.ContactsContract.CommonDataKinds.StructuredName
import android.telephony.SmsManager
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    data class C(val id: Long, val key: String, val name: String, val num: String)

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private lateinit var content: FrameLayout
    private var tab = 0
    private var inThread = false

    private val perms = arrayOf(
        Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS,
        Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS,
        Manifest.permission.RECEIVE_SMS, Manifest.permission.CALL_PHONE,
        Manifest.permission.READ_CALL_LOG
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val bar = LinearLayout(this)
        listOf("Dial", "Calls", "SMS", "Contacts", "More").forEachIndexed { i, t ->
            bar.addView(Button(this).apply {
                text = t; textSize = 11f; isAllCaps = false
                setOnClickListener { go(i) }
            }, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        root.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)
        val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1) else go(0)
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r); go(tab)
    }

    override fun onBackPressed() {
        if (inThread) go(2) else super.onBackPressed()
    }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun vbox() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
    private fun fmt(ms: Long) = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date(ms))

    private fun go(i: Int) {
        tab = i; inThread = false
        content.removeAllViews()
        content.addView(when (i) {
            0 -> dialView(); 1 -> callsView(); 2 -> smsView(); 3 -> contactsView(); else -> moreView()
        })
    }

    private fun list(items: List<String>, onClick: (Int) -> Unit) = ListView(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_list_item_1, items)
        setOnItemClickListener { _, _, i, _ -> onClick(i) }
    }

    private fun call(n: String) {
        if (n.isBlank()) return
        val u = Uri.parse("tel:" + Uri.encode(n))
        try { startActivity(Intent(Intent.ACTION_CALL, u)) }
        catch (e: Exception) { startActivity(Intent(Intent.ACTION_DIAL, u)) }
    }

    private fun t9(s: String) = s.lowercase().map {
        when (it) {
            in 'a'..'c' -> '2'; in 'd'..'f' -> '3'; in 'g'..'i' -> '4'; in 'j'..'l' -> '5'
            in 'm'..'o' -> '6'; in 'p'..'s' -> '7'; in 't'..'v' -> '8'; in 'w'..'z' -> '9'
            in '0'..'9' -> it; else -> ' '
        }
    }.joinToString("")

    // ---------- data ----------
    private fun loadContacts(): List<C> {
        val out = ArrayList<C>()
        try {
            contentResolver.query(
                Phone.CONTENT_URI,
                arrayOf(Phone.CONTACT_ID, Phone.LOOKUP_KEY, Phone.DISPLAY_NAME, Phone.NUMBER),
                null, null, Phone.DISPLAY_NAME + " ASC"
            )?.use { c ->
                while (c.moveToNext())
                    out.add(C(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: ""))
            }
        } catch (e: Exception) { }
        return out
    }

    private fun addContact(name: String, num: String) {
        val ops = ArrayList<ContentProviderOperation>()
        ops.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
            .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
            .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null).build())
        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
            .withValue(ContactsContract.Data.MIMETYPE, StructuredName.CONTENT_ITEM_TYPE)
            .withValue(StructuredName.DISPLAY_NAME, name).build())
        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
            .withValue(ContactsContract.Data.MIMETYPE, Phone.CONTENT_ITEM_TYPE)
            .withValue(Phone.NUMBER, num)
            .withValue(Phone.TYPE, Phone.TYPE_MOBILE).build())
        contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
    }

    // ---------- Dialer ----------
    private fun dialView(): View {
        val col = vbox().apply { setPadding(dp(8), dp(8), dp(8), dp(8)) }
        val num = EditText(this).apply {
            textSize = 28f; gravity = Gravity.CENTER; hint = "Number / Name"
            inputType = InputType.TYPE_CLASS_PHONE; showSoftInputOnFocus = false
        }
        val matches = vbox()
        val all = loadContacts()
        num.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                matches.removeAllViews()
                val d = s.toString()
                if (d.isEmpty()) return
                all.filter { t9(it.name).contains(d) || it.num.filter { ch -> ch.isDigit() }.contains(d) }
                    .take(3).forEach { c ->
                        matches.addView(TextView(this@MainActivity).apply {
                            text = c.name + "  " + c.num; textSize = 16f
                            setPadding(dp(12), dp(8), dp(12), dp(8))
                            setOnClickListener { num.setText(c.num) }
                        })
                    }
            }
        })
        col.addView(num); col.addView(matches)
        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#")
        for (r in 0 until 4) {
            val row = LinearLayout(this)
            for (k in 0 until 3) {
                val key = keys[r * 3 + k]
                row.addView(Button(this).apply {
                    text = key; textSize = 22f; setOnClickListener { num.append(key) }
                }, LinearLayout.LayoutParams(0, dp(64), 1f))
            }
            col.addView(row)
        }
        val last = LinearLayout(this)
        last.addView(btn("⌫") {
            val t = num.text.toString(); if (t.isNotEmpty()) num.setText(t.dropLast(1))
        }, LinearLayout.LayoutParams(0, dp(64), 1f))
        last.addView(btn("Call") { call(num.text.toString()) }, LinearLayout.LayoutParams(0, dp(64), 2f))
        col.addView(last)
        return col
    }

    // ---------- Call log ----------
    private fun callsView(): View {
        val rows = ArrayList<String>(); val nums = ArrayList<String>()
        try {
            contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE),
                null, null, CallLog.Calls.DATE + " DESC"
            )?.use { c ->
                while (c.moveToNext() && rows.size < 200) {
                    val n = c.getString(0) ?: ""
                    val nm = c.getString(1)
                    val t = when (c.getInt(2)) { 1 -> "Received"; 2 -> "Outgoing"; 3 -> "Missed"; else -> "Other" }
                    rows.add((if (nm.isNullOrBlank()) n else nm) + "\n" + t + " · " + fmt(c.getLong(3)))
                    nums.add(n)
                }
            }
        } catch (e: Exception) { }
        return list(rows) { call(nums[it]) }
    }

    // ---------- SMS ----------
    private fun smsView(): View {
        val col = vbox()
        col.addView(btn("+ New message") {
            val e = EditText(this).apply { hint = "Number"; inputType = InputType.TYPE_CLASS_PHONE }
            AlertDialog.Builder(this).setView(e)
                .setPositiveButton("OK") { _, _ -> if (e.text.isNotBlank()) threadView(e.text.toString().trim()) }
                .show()
        })
        val seen = LinkedHashMap<String, String>()
        try {
            contentResolver.query(Uri.parse("content://sms"), arrayOf("address", "body"), null, null, "date DESC")
                ?.use { c ->
                    while (c.moveToNext()) {
                        val a = c.getString(0) ?: continue
                        if (!seen.containsKey(a)) seen[a] = c.getString(1) ?: ""
                    }
                }
        } catch (e: Exception) { }
        val keys = seen.keys.toList()
        col.addView(list(keys.map { it + "\n" + seen[it]!!.take(60) }) { threadView(keys[it]) },
            LinearLayout.LayoutParams(MATCH, 0, 1f))
        return col
    }

    private fun threadView(addr: String) {
        inThread = true
        val items = ArrayList<String>()
        try {
            contentResolver.query(Uri.parse("content://sms"), arrayOf("body", "type"),
                "address=?", arrayOf(addr), "date ASC")?.use { c ->
                while (c.moveToNext())
                    items.add((if (c.getInt(1) == 1) "← " else "→ ") + (c.getString(0) ?: ""))
            }
        } catch (e: Exception) { }
        val ad = ArrayAdapter(this, android.R.layout.simple_list_item_1, items)
        val lv = ListView(this).apply { adapter = ad; setSelection(items.size - 1) }
        val box = EditText(this).apply { hint = "Message" }
        val row = LinearLayout(this)
        row.addView(box, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(btn("Send") {
            val t = box.text.toString()
            if (t.isNotBlank()) try {
                @Suppress("DEPRECATION") val sm = SmsManager.getDefault()
                sm.sendMultipartTextMessage(addr, null, sm.divideMessage(t), null, null)
                items.add("→ $t"); ad.notifyDataSetChanged(); box.setText("")
            } catch (e: Exception) { toast("Send failed") }
        })
        val col = vbox()
        col.addView(TextView(this).apply { text = addr; textSize = 18f; setPadding(dp(12), dp(12), dp(12), dp(12)) })
        col.addView(lv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        col.addView(row)
        content.removeAllViews(); content.addView(col)
    }

    // ---------- Contacts ----------
    private fun contactsView(): View {
        val col = vbox()
        col.addView(btn("+ Add contact") {
            val n = EditText(this).apply { hint = "Name" }
            val p = EditText(this).apply { hint = "Number"; inputType = InputType.TYPE_CLASS_PHONE }
            val b = vbox().apply { setPadding(dp(16), dp(8), dp(16), dp(8)); addView(n); addView(p) }
            AlertDialog.Builder(this).setView(b).setPositiveButton("Save") { _, _ ->
                try { addContact(n.text.toString(), p.text.toString()) } catch (e: Exception) { toast("Failed") }
                go(3)
            }.show()
        })
        val cs = loadContacts()
        col.addView(list(cs.map { it.name + "\n" + it.num }) { i ->
            val c = cs[i]
            val uri = ContactsContract.Contacts.getLookupUri(c.id, c.key)
            AlertDialog.Builder(this).setTitle(c.name).setItems(arrayOf("Call", "Edit", "Delete")) { _, w ->
                when (w) {
                    0 -> call(c.num)
                    1 -> startActivity(Intent(Intent.ACTION_EDIT).setDataAndType(uri, ContactsContract.Contacts.CONTENT_ITEM_TYPE))
                    else -> { try { contentResolver.delete(uri, null, null) } catch (e: Exception) { }; go(3) }
                }
            }.show()
        }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return col
    }

    // ---------- More: backup / restore / about ----------
    private fun moreView(): View {
        val col = vbox().apply { setPadding(dp(16), dp(16), dp(16), dp(16)) }
        col.addView(btn("Backup (Contacts + SMS → JSON)") {
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
                putExtra(Intent.EXTRA_TITLE, "simple_phone_backup.json")
            }, 10)
        })
        col.addView(btn("Restore from JSON file") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            }, 11)
        })
        col.addView(TextView(this).apply {
            text = "\nSimple Phone v1.0\n\nCreator: Mohammod Abdul Awal\nStudent: Department of English, National University."
            textSize = 16f
        })
        return col
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        Thread {
            val msg = try { if (req == 10) doBackup(uri) else doRestore(uri) } catch (e: Exception) { "Error: " + e.message }
            runOnUiThread { toast(msg) }
        }.start()
    }

    private fun doBackup(uri: Uri): String {
        val cs = JSONArray()
        loadContacts().forEach { cs.put(JSONObject().put("name", it.name).put("number", it.num)) }
        val ms = JSONArray()
        contentResolver.query(Uri.parse("content://sms"), arrayOf("address", "body", "date", "type"), null, null, "date ASC")
            ?.use { c ->
                while (c.moveToNext()) ms.put(JSONObject()
                    .put("address", c.getString(0) ?: "").put("body", c.getString(1) ?: "")
                    .put("date", c.getLong(2)).put("type", c.getInt(3)))
            }
        val root = JSONObject().put("contacts", cs).put("sms", ms)
        contentResolver.openOutputStream(uri)?.use { it.write(root.toString().toByteArray()) }
        return "Backup done: ${cs.length()} contacts, ${ms.length()} SMS"
    }

    private fun doRestore(uri: Uri): String {
        val txt = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
        val root = JSONObject(txt)
        val have = loadContacts().map { it.name + "|" + it.num }.toHashSet()
        var cc = 0; var sc = 0
        val cs = root.optJSONArray("contacts") ?: JSONArray()
        for (i in 0 until cs.length()) {
            val o = cs.getJSONObject(i)
            if (have.contains(o.getString("name") + "|" + o.getString("number"))) continue
            try { addContact(o.getString("name"), o.getString("number")); cc++ } catch (e: Exception) { }
        }
        val ms = root.optJSONArray("sms") ?: JSONArray()
        for (i in 0 until ms.length()) {
            val o = ms.getJSONObject(i)
            try {
                val v = ContentValues().apply {
                    put("address", o.getString("address")); put("body", o.getString("body"))
                    put("date", o.getLong("date")); put("type", o.getInt("type")); put("read", 1)
                }
                if (contentResolver.insert(Uri.parse("content://sms"), v) != null) sc++
            } catch (e: Exception) { }
        }
        return "Restored: $cc contacts, $sc SMS (SMS restore needs default SMS app)"
    }
}
