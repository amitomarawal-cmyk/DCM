package com.example.simplephone

import android.Manifest
import android.app.*
import android.app.role.RoleManager
import android.content.*
import android.net.Uri
import android.os.*
import android.provider.*
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.ContactsContract.CommonDataKinds.StructuredName
import android.provider.ContactsContract.Data
import android.provider.ContactsContract.RawContacts
import android.telephony.SmsManager
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.*
import android.widget.*
import org.json.*

class MainActivity : Activity() {
    private lateinit var body: FrameLayout
    private var tab = 0
    private var pending: Uri? = null
    private val perms = arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS, Manifest.permission.CALL_PHONE,
        Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS)

    private fun Int.dp() = (this * resources.displayMetrics.density).toInt()
    private fun lp(w: Int = MATCH_PARENT, h: Int = WRAP_CONTENT, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { f() } }
    private fun vbox() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun norm(s: String) = s.filter { it.isDigit() }.takeLast(10)
    private fun isDefault() = Telephony.Sms.getDefaultSmsPackage(this) == packageName

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        requestPermissions(perms, 1)
        val root = vbox().apply { fitsSystemWindows = true }
        body = FrameLayout(this)
        root.addView(body, lp(h = 0, wt = 1f))
        val bar = LinearLayout(this)
        listOf("Contacts", "Dialer", "SMS", "Backup").forEachIndexed { i, t -> bar.addView(btn(t) { show(i) }, lp(0, WRAP_CONTENT, 1f)) }
        root.addView(bar)
        setContentView(root)
        val n = intent?.data?.schemeSpecificPart
        if (n.isNullOrBlank()) show(0) else thread(n)
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) = show(tab)

    private fun show(i: Int) {
        tab = i; body.removeAllViews()
        body.addView(when (i) { 0 -> contactsView(); 1 -> dialerView(); 2 -> smsView(); else -> backupView() })
    }

    /* ---------- contacts ---------- */
    private fun contacts(): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        try {
            contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, Phone.DISPLAY_NAME + " COLLATE NOCASE")?.use { c ->
                while (c.moveToNext()) out.add((c.getString(0) ?: "") to (c.getString(1) ?: ""))
            }
        } catch (e: Exception) {}
        return out
    }

    private fun contactsView(): View {
        val items = contacts()
        val l = ListView(this)
        l.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items.map { it.first + "\n" + it.second })
        l.setOnItemClickListener { _, _, i, _ ->
            val n = items[i].second
            AlertDialog.Builder(this).setTitle(items[i].first).setItems(arrayOf("Call", "Message")) { _, w -> if (w == 0) call(n) else thread(n) }.show()
        }
        return vbox().apply {
            addView(btn("+ New contact") { startActivity(Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI)) })
            addView(l, lp(h = 0, wt = 1f))
        }
    }

    /* ---------- dialer ---------- */
    private fun call(n: String) {
        if (n.isBlank()) return
        val u = Uri.parse("tel:" + Uri.encode(n))
        try { startActivity(Intent(Intent.ACTION_CALL, u)) } catch (e: SecurityException) { startActivity(Intent(Intent.ACTION_DIAL, u)) }
    }

    private fun dialerView(): View {
        val t = TextView(this).apply { textSize = 32f; gravity = Gravity.CENTER; setPadding(0, 32.dp(), 0, 32.dp()) }
        val c = vbox().apply { addView(t) }
        listOf("123", "456", "789", "*0#").forEach { r ->
            val row = LinearLayout(this)
            r.forEach { ch -> row.addView(btn(ch.toString()) { t.append(ch.toString()) }.apply { textSize = 24f }, lp(0, 72.dp(), 1f)) }
            c.addView(row)
        }
        val last = LinearLayout(this)
        last.addView(btn("⌫") { t.text = t.text.dropLast(1) }, lp(0, 72.dp(), 1f))
        last.addView(btn("Call") { call(t.text.toString()) }, lp(0, 72.dp(), 2f))
        c.addView(last)
        return c
    }

    /* ---------- messages ---------- */
    private fun smsView(): View {
        val seen = LinkedHashMap<String, String>()
        try {
            contentResolver.query(Telephony.Sms.CONTENT_URI, arrayOf("address", "body"), null, null, "date DESC")?.use { c ->
                while (c.moveToNext()) { val a = c.getString(0) ?: continue; if (a !in seen) seen[a] = c.getString(1) ?: "" }
            }
        } catch (e: Exception) {}
        val keys = seen.keys.toList()
        val l = ListView(this)
        l.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, keys.map { it + "\n" + (seen[it] ?: "").take(60) })
        l.setOnItemClickListener { _, _, i, _ -> thread(keys[i]) }
        return vbox().apply {
            addView(btn("+ New message") {
                val e = EditText(this@MainActivity).apply { hint = "Number" }
                AlertDialog.Builder(this@MainActivity).setView(e).setPositiveButton("OK") { _, _ -> thread(e.text.toString()) }.show()
            })
            addView(l, lp(h = 0, wt = 1f))
        }
    }

    private fun thread(a: String) {
        tab = 2; body.removeAllViews()
        val msgs = ArrayList<String>()
        try {
            contentResolver.query(Telephony.Sms.CONTENT_URI, arrayOf("body", "type"), "address=?", arrayOf(a), "date ASC")?.use { c ->
                while (c.moveToNext()) msgs.add((if (c.getInt(1) == 2) "Me: " else "") + c.getString(0))
            }
        } catch (e: Exception) {}
        val l = ListView(this)
        l.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, msgs)
        l.setSelection(msgs.size)
        val e = EditText(this).apply { hint = "Message" }
        val row = LinearLayout(this)
        row.addView(e, lp(0, WRAP_CONTENT, 1f))
        row.addView(btn("Send") { send(a, e.text.toString()); thread(a) })
        body.addView(vbox().apply { addView(btn("← $a") { show(2) }); addView(l, lp(h = 0, wt = 1f)); addView(row) })
    }

    @Suppress("DEPRECATION")
    private fun send(a: String, t: String) {
        if (t.isBlank()) return
        try {
            val m = SmsManager.getDefault()
            m.sendMultipartTextMessage(a, null, m.divideMessage(t), null, null)
            if (isDefault()) contentResolver.insert(Telephony.Sms.Sent.CONTENT_URI, ContentValues().apply {
                put("address", a); put("body", t); put("date", System.currentTimeMillis()) })
        } catch (e: Exception) { toast("Send failed: ${e.message}") }
    }

    /* ---------- backup / restore ---------- */
    private fun backupView(): View = vbox().apply {
        setPadding(16.dp(), 16.dp(), 16.dp(), 16.dp())
        addView(btn("Backup contacts") { pick(10, "contacts_backup.json") })
        addView(btn("Restore contacts") { pick(20, null) })
        addView(btn("Backup messages") { pick(11, "messages_backup.json") })
        addView(btn("Restore messages") { pick(21, null) })
        addView(btn("Make this the default SMS app") { askRole() })
        addView(TextView(this@MainActivity).apply { setPadding(0, 16.dp(), 0, 0)
            text = "Restoring messages needs this app to be the default SMS app for a moment. Afterwards, set your old SMS app as default again in Settings." })
    }

    private fun pick(code: Int, name: String?) {
        val i = Intent(if (name != null) Intent.ACTION_CREATE_DOCUMENT else Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
        if (name != null) i.setType("application/json").putExtra(Intent.EXTRA_TITLE, name) else i.setType("*/*")
        startActivityForResult(i, code)
    }

    private fun askRole() {
        if (Build.VERSION.SDK_INT >= 29) startActivityForResult(getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_SMS), 30)
        else startActivityForResult(Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT).putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName), 30)
    }

    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        val u = d?.data
        if (r == 30) { val p = pending; pending = null; if (isDefault() && p != null) work { restoreSms(p) } else if (!isDefault()) toast("Not set as default"); return }
        if (res != RESULT_OK || u == null) return
        when (r) {
            10 -> work { backupContacts(u) }
            11 -> work { backupSms(u) }
            20 -> work { restoreContacts(u) }
            21 -> if (isDefault()) work { restoreSms(u) } else { pending = u; askRole() }
        }
    }

    private fun work(f: () -> String) {
        toast("Working…")
        Thread { val r = try { f() } catch (e: Exception) { "Failed: ${e.message}" }; runOnUiThread { toast(r) } }.start()
    }

    private fun read(u: Uri) = contentResolver.openInputStream(u)!!.bufferedReader().use { it.readText() }
    private fun write(u: Uri, s: String) = contentResolver.openOutputStream(u, "wt")!!.bufferedWriter().use { it.write(s) }

    private fun backupContacts(u: Uri): String {
        val m = LinkedHashMap<String, JSONArray>()
        contacts().forEach { (n, p) -> m.getOrPut(n) { JSONArray() }.put(p) }
        val a = JSONArray()
        m.forEach { (n, p) -> a.put(JSONObject().put("n", n).put("p", p)) }
        write(u, a.toString())
        return "${a.length()} contacts saved"
    }

    private fun restoreContacts(u: Uri): String {
        val have = contacts().map { norm(it.second) }.toHashSet()
        val a = JSONArray(read(u)); val ops = ArrayList<ContentProviderOperation>(); var n = 0
        for (i in 0 until a.length()) {
            if (ops.size > 300) { contentResolver.applyBatch(ContactsContract.AUTHORITY, ops); ops.clear() }
            val o = a.getJSONObject(i); val p = o.getJSONArray("p")
            if ((0 until p.length()).any { norm(p.getString(it)) in have }) continue
            val r = ops.size
            ops.add(ContentProviderOperation.newInsert(RawContacts.CONTENT_URI).withValue(RawContacts.ACCOUNT_TYPE, null).withValue(RawContacts.ACCOUNT_NAME, null).build())
            ops.add(ContentProviderOperation.newInsert(Data.CONTENT_URI).withValueBackReference(Data.RAW_CONTACT_ID, r)
                .withValue(Data.MIMETYPE, StructuredName.CONTENT_ITEM_TYPE).withValue(StructuredName.DISPLAY_NAME, o.getString("n")).build())
            for (j in 0 until p.length()) ops.add(ContentProviderOperation.newInsert(Data.CONTENT_URI).withValueBackReference(Data.RAW_CONTACT_ID, r)
                .withValue(Data.MIMETYPE, Phone.CONTENT_ITEM_TYPE).withValue(Phone.NUMBER, p.getString(j)).withValue(Phone.TYPE, Phone.TYPE_MOBILE).build())
            n++
        }
        if (ops.isNotEmpty()) contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
        return "$n contacts restored"
    }

    private fun backupSms(u: Uri): String {
        val a = JSONArray()
        contentResolver.query(Telephony.Sms.CONTENT_URI, arrayOf("address", "body", "date", "type"), null, null, "date ASC")?.use { c ->
            while (c.moveToNext()) a.put(JSONObject().put("a", c.getString(0)).put("b", c.getString(1)).put("d", c.getLong(2)).put("t", c.getInt(3)))
        }
        write(u, a.toString())
        return "${a.length()} messages saved"
    }

    private fun restoreSms(u: Uri): String {
        val have = HashSet<String>()
        contentResolver.query(Telephony.Sms.CONTENT_URI, arrayOf("address", "date"), null, null, null)?.use { c ->
            while (c.moveToNext()) have.add(c.getString(0) + "|" + c.getLong(1))
        }
        val a = JSONArray(read(u)); var n = 0
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if ((o.optString("a") + "|" + o.getLong("d")) in have) continue
            contentResolver.insert(Telephony.Sms.CONTENT_URI, ContentValues().apply {
                put("address", o.optString("a")); put("body", o.optString("b")); put("date", o.getLong("d")); put("type", o.getInt("t")); put("read", 1) })
            n++
        }
        return "$n messages restored. Set your old SMS app as default again in Settings."
    }
}

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        for (m in Telephony.Sms.Intents.getMessagesFromIntent(i))
            c.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, ContentValues().apply {
                put("address", m.originatingAddress); put("body", m.messageBody); put("date", System.currentTimeMillis()) })
    }
}
class MmsReceiver : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) {} }
class RespondService : Service() { override fun onBind(i: Intent?): IBinder? = null }
