package com.example.simplephone

import android.app.*
import android.content.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.telecom.*
import android.view.Gravity
import android.widget.*

object Block {
    private fun p(c: Context) = c.getSharedPreferences("blocked", 0)
    fun norm(s: String) = s.filter { it.isDigit() }.takeLast(10)
    fun all(c: Context): Set<String> = p(c).getStringSet("n", emptySet()) ?: emptySet()
    fun has(c: Context, n: String): Boolean { val k = norm(n); return k.isNotEmpty() && k in all(c) }
    fun add(c: Context, n: String) { val k = norm(n); if (k.isNotEmpty()) p(c).edit().putStringSet("n", all(c) + k).apply() }
    fun del(c: Context, k: String) = p(c).edit().putStringSet("n", all(c) - k).apply()
}

object Hold { val calls = ArrayList<Call>(); var svc: InCallService? = null; var ui: (() -> Unit)? = null }

fun Call.num(): String = details.handle?.schemeSpecificPart ?: ""

class CallService : InCallService() {
    private val cb = object : Call.Callback() { override fun onStateChanged(c: Call, s: Int) { Hold.ui?.invoke() } }
    override fun onCreate() { super.onCreate(); Hold.svc = this }
    override fun onDestroy() { Hold.svc = null; Hold.calls.clear(); super.onDestroy() }

    override fun onCallAdded(c: Call) {
        if (c.state == Call.STATE_RINGING && Block.has(this, c.num())) { c.reject(false, null); return }
        Hold.calls.add(c); c.registerCallback(cb)
        val i = Intent(this, CallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (c.state == Call.STATE_RINGING) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("calls", "Calls", NotificationManager.IMPORTANCE_HIGH))
            val pi = PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE)
            nm.notify(1, Notification.Builder(this, "calls").setSmallIcon(android.R.drawable.sym_call_incoming).setContentTitle("Incoming call")
                .setContentText(c.num()).setCategory(Notification.CATEGORY_CALL).setFullScreenIntent(pi, true).setContentIntent(pi).build())
        }
        try { startActivity(i) } catch (e: Exception) {}
        Hold.ui?.invoke()
    }

    override fun onCallRemoved(c: Call) {
        c.unregisterCallback(cb); Hold.calls.remove(c)
        getSystemService(NotificationManager::class.java).cancel(1)
        Hold.ui?.invoke()
    }
}

class CallActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var status: TextView
    private lateinit var ans: Button
    private lateinit var end: Button
    private var muted = false
    private var spk = false
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun b(t: String, f: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; textSize = 18f; setOnClickListener { f() } }
    private fun cur() = Hold.calls.lastOrNull()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        info = TextView(this).apply { textSize = 30f; gravity = Gravity.CENTER; setPadding(0, dp(48), 0, dp(8)) }
        status = TextView(this).apply { textSize = 18f; gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(32)) }
        ans = b("Answer") { cur()?.answer(0) }
        end = b("End") { cur()?.let { if (it.state == Call.STATE_RINGING) it.reject(false, null) else it.disconnect() } }
        val row = LinearLayout(this)
        row.addView(b("Mute") { muted = !muted; Hold.svc?.setMuted(muted) }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(b("Speaker") { spk = !spk; Hold.svc?.setAudioRoute(if (spk) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_EARPIECE) }, LinearLayout.LayoutParams(0, -2, 1f))
        val blk = b("Block this number") {
            cur()?.let { Block.add(this, it.num()); Toast.makeText(this, "Blocked", Toast.LENGTH_SHORT).show(); if (it.state == Call.STATE_RINGING) it.reject(false, null) else it.disconnect() }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(24), dp(24), dp(24))
            addView(info); addView(status); addView(ans); addView(end); addView(row); addView(blk)
        })
        Hold.ui = { refresh() }
        refresh()
    }

    override fun onDestroy() { Hold.ui = null; super.onDestroy() }

    private fun nameOf(n: String): String {
        if (n.isEmpty()) return "Unknown"
        try {
            contentResolver.query(Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(n)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) return it.getString(0) + "\n" + n }
        } catch (e: Exception) {}
        return n
    }

    private fun refresh() {
        val c = cur() ?: run { finish(); return }
        info.text = nameOf(c.num())
        status.text = when (c.state) {
            Call.STATE_RINGING -> "Incoming call"
            Call.STATE_DIALING, Call.STATE_CONNECTING -> "Calling…"
            Call.STATE_ACTIVE -> "On call"
            Call.STATE_HOLDING -> "On hold"
            else -> "Ending…"
        }
        ans.visibility = if (c.state == Call.STATE_RINGING) android.view.View.VISIBLE else android.view.View.GONE
        end.text = if (c.state == Call.STATE_RINGING) "Reject" else "End call"
    }
}
