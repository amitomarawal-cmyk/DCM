package com.awal.litebrowser;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {

    static final String HOME = "file:///android_asset/newtab.html";
    static final String AI_URL = "https://www.google.com/search?udm=50";
    static final String DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

    static class Tab {
        WebView web;
        String title = "New tab";
        String url = "";
        String defaultUa = "";
        boolean desktop = false;
    }

    private final ArrayList<Tab> tabs = new ArrayList<>();
    private int cur = -1;
    private boolean full = false;      // full screen mode on
    private boolean barsOn = true;     // top/bottom bars visible
    private boolean menuOpen = false;
    private float touchY0;
    private boolean twoFinger;
    private final Handler h = new Handler(Looper.getMainLooper());

    private FrameLayout root, webBox;
    private LinearLayout toolbar, bottomBar, switcher;
    private EditText urlBar;
    private TextView siteIcon, tabBtn, menuBtn, swExit, swTitle;
    private ProgressBar progress;
    private GridLayout grid;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private PopupWindow menuPw;

    private final Runnable hideRun = new Runnable() {
        @Override
        public void run() {
            if (!full || !barsOn) return;
            if (urlBar.hasFocus() || menuOpen || switcher.getVisibility() == View.VISIBLE) {
                h.postDelayed(this, 3000);
            } else {
                barsOn = false;
                applyBars();
            }
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        root = findViewById(R.id.root);
        webBox = findViewById(R.id.webBox);
        toolbar = findViewById(R.id.toolbar);
        bottomBar = findViewById(R.id.bottomBar);
        switcher = findViewById(R.id.switcher);
        urlBar = findViewById(R.id.urlBar);
        siteIcon = findViewById(R.id.siteIcon);
        tabBtn = findViewById(R.id.tabBtn);
        menuBtn = findViewById(R.id.menuBtn);
        swExit = findViewById(R.id.swExit);
        swTitle = findViewById(R.id.swTitle);
        progress = findViewById(R.id.progress);
        grid = findViewById(R.id.grid);

        urlBar.setOnEditorActionListener((v, a, e) -> {
            go(urlBar.getText().toString());
            hideKeyboard();
            urlBar.clearFocus();
            return true;
        });
        tabBtn.setOnClickListener(v -> showSwitcher());
        menuBtn.setOnClickListener(v -> showMenu());
        findViewById(R.id.homeBtn).setOnClickListener(v -> tabs.get(cur).web.loadUrl(HOME));
        findViewById(R.id.aiBtn).setOnClickListener(v -> tabs.get(cur).web.loadUrl(AI_URL));
        findViewById(R.id.plusBtn).setOnClickListener(v -> newTab(HOME));
        findViewById(R.id.swNew).setOnClickListener(v -> newTab(HOME));
        findViewById(R.id.swAbout).setOnClickListener(v -> showAbout());
        swExit.setOnClickListener(v -> {
            setFull(false);
            hideSwitcher();
        });

        applySystemUi();
        Uri d = getIntent().getData();
        newTab(d != null ? d.toString() : HOME);
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        if (i.getData() != null) newTab(i.getData().toString());
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) applySystemUi();
    }

    @Override
    protected void onDestroy() {
        for (Tab t : tabs) t.web.destroy();
        super.onDestroy();
    }

    // ---------- Tabs ----------
    private String clean(String u) {
        return (u == null || u.startsWith("file:///android_asset")) ? "" : u;
    }

    private WebView makeWeb(final Tab t) {
        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        t.defaultUa = s.getUserAgentString();
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);

        // Full screen: swipe up anywhere (2 fingers, or at page bottom) reveals the bars
        w.setOnTouchListener((v, e) -> {
            if (full && !barsOn) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        touchY0 = e.getRawY();
                        twoFinger = false;
                        break;
                    case MotionEvent.ACTION_POINTER_DOWN:
                        twoFinger = true;
                        break;
                    case MotionEvent.ACTION_UP:
                        if (touchY0 - e.getRawY() > dp(70) && (twoFinger || !v.canScrollVertically(1))) {
                            showBars();
                        }
                        break;
                }
            }
            return false;
        });

        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("http://") || u.startsWith("https://") || u.startsWith("about:")) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String u, Bitmap f) {
                t.url = clean(u);
                if (isCur(t)) refreshBar();
            }

            @Override
            public void onPageFinished(WebView v, String u) {
                t.url = clean(u);
                if (isCur(t)) refreshBar();
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                if (isCur(t)) {
                    progress.setProgress(p);
                    progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
                }
            }

            @Override
            public void onReceivedTitle(WebView v, String title) {
                t.title = title;
            }

            @Override
            public void onShowCustomView(View v, CustomViewCallback cb) {
                if (customView != null) {
                    cb.onCustomViewHidden();
                    return;
                }
                customView = v;
                customCb = cb;
                root.addView(v, new FrameLayout.LayoutParams(-1, -1));
                applySystemUi();
            }

            @Override
            public void onHideCustomView() {
                hideCustom();
            }
        });

        w.setDownloadListener((u, ua, cd, mime, len) -> {
            try {
                DownloadManager.Request r = new DownloadManager.Request(Uri.parse(u));
                r.setMimeType(mime);
                r.addRequestHeader("User-Agent", ua);
                String c = CookieManager.getInstance().getCookie(u);
                if (c != null) r.addRequestHeader("Cookie", c);
                String fn = URLUtil.guessFileName(u, cd, mime);
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fn);
                ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
                Toast.makeText(this, "Downloading: " + fn, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Download failed", Toast.LENGTH_SHORT).show();
            }
        });
        return w;
    }

    private boolean isCur(Tab t) {
        return cur >= 0 && cur < tabs.size() && tabs.get(cur) == t;
    }

    private void newTab(String url) {
        Tab t = new Tab();
        t.web = makeWeb(t);
        tabs.add(t);
        select(tabs.size() - 1);
        t.web.loadUrl(url);
        hideSwitcher();
    }

    // Each tab = its own WebView. Background tabs are paused and detached.
    private void select(int i) {
        if (cur >= 0 && cur < tabs.size()) {
            Tab o = tabs.get(cur);
            o.web.onPause();
            webBox.removeView(o.web);
        }
        cur = i;
        Tab t = tabs.get(i);
        webBox.addView(t.web, new FrameLayout.LayoutParams(-1, -1));
        t.web.onResume();
        urlBar.clearFocus();
        progress.setVisibility(View.GONE);
        refreshBar();
    }

    private void closeTab(int i) {
        Tab t = tabs.get(i);
        if (tabs.size() == 1) {
            t.web.loadUrl(HOME);
            hideSwitcher();
            return;
        }
        boolean wasCur = (i == cur);
        if (wasCur) {
            webBox.removeView(t.web);
            cur = -1;
        }
        tabs.remove(i);
        t.web.destroy();
        if (wasCur) select(Math.min(i, tabs.size() - 1));
        else if (i < cur) cur--;
        refreshBar();
        buildGrid();
    }

    private void refreshBar() {
        if (cur < 0 || cur >= tabs.size()) return;
        Tab t = tabs.get(cur);
        if (!urlBar.hasFocus()) urlBar.setText(t.url);
        siteIcon.setText(t.url.isEmpty() ? "🔍" : (t.url.startsWith("https") ? "🔒" : "⚠"));
        tabBtn.setText(String.valueOf(tabs.size()));
    }

    private void go(String in) {
        String s = in.trim();
        if (s.isEmpty()) return;
        String u;
        if (s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) {
            u = s;
        } else if (s.contains(" ") || !s.contains(".")) {
            u = "https://www.google.com/search?q=" + Uri.encode(s);
        } else {
            u = "https://" + s;
        }
        tabs.get(cur).web.loadUrl(u);
    }

    // ---------- Tab switcher ----------
    private void showSwitcher() {
        hideKeyboard();
        buildGrid();
        switcher.setVisibility(View.VISIBLE);
    }

    private void hideSwitcher() {
        switcher.setVisibility(View.GONE);
    }

    private void buildGrid() {
        grid.removeAllViews();
        swTitle.setText("Tabs (" + tabs.size() + ")");
        for (int i = 0; i < tabs.size(); i++) {
            final int idx = i;
            Tab t = tabs.get(i);

            LinearLayout c = new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL);
            c.setPadding(dp(12), dp(8), dp(12), dp(10));
            GradientDrawable g = new GradientDrawable();
            g.setColor(Color.WHITE);
            g.setCornerRadius(dp(16));
            if (i == cur) g.setStroke(dp(2), 0xFF1A73E8);
            c.setBackground(g);
            c.setOnClickListener(v -> {
                select(idx);
                hideSwitcher();
            });

            LinearLayout head = new LinearLayout(this);
            head.setGravity(Gravity.CENTER_VERTICAL);
            TextView title = new TextView(this);
            title.setText(t.title);
            title.setSingleLine(true);
            title.setEllipsize(android.text.TextUtils.TruncateAt.END);
            title.setTextColor(0xFF202124);
            title.setTextSize(14);
            head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
            TextView x = new TextView(this);
            x.setText("✕");
            x.setTextSize(16);
            x.setTextColor(0xFF5F6368);
            x.setPadding(dp(8), dp(4), dp(4), dp(4));
            x.setOnClickListener(v -> closeTab(idx));
            head.addView(x);
            c.addView(head);

            TextView u = new TextView(this);
            u.setText(t.url.isEmpty() ? "New tab" : t.url);
            u.setMaxLines(3);
            u.setEllipsize(android.text.TextUtils.TruncateAt.END);
            u.setTextColor(0xFF5F6368);
            u.setTextSize(12);
            u.setPadding(0, dp(8), 0, 0);
            c.addView(u);

            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                    GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
            lp.width = 0;
            lp.height = dp(130);
            lp.setMargins(dp(6), dp(6), dp(6), dp(6));
            grid.addView(c, lp);
        }
    }

    // ---------- Chrome-style menu ----------
    private View.OnClickListener act(final Runnable r) {
        return v -> {
            if (menuPw != null) menuPw.dismiss();
            r.run();
        };
    }

    private TextView circle(String glyph, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(glyph);
        t.setGravity(Gravity.CENTER);
        t.setTextSize(19);
        t.setTextColor(0xFF1F1F1F);
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(0xFFE9E4D8);
        t.setBackground(d);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(44), dp(44));
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        t.setLayoutParams(lp);
        return t;
    }

    private void item(LinearLayout box, String icon, String label, Runnable r) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), 0, dp(14), 0);
        TextView i = new TextView(this);
        i.setText(icon);
        i.setTextSize(18);
        i.setGravity(Gravity.CENTER);
        i.setTextColor(0xFF444746);
        row.addView(i, new LinearLayout.LayoutParams(dp(32), -2));
        TextView l = new TextView(this);
        l.setText(label);
        l.setTextSize(16);
        l.setTextColor(0xFF1F1F1F);
        l.setPadding(dp(14), 0, 0, 0);
        row.addView(l);
        row.setOnClickListener(act(r));
        box.addView(row, new LinearLayout.LayoutParams(-1, dp(48)));
    }

    private void showMenu() {
        final Tab t = tabs.get(cur);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(8), dp(8), dp(8), dp(8));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_HORIZONTAL);
        row.addView(circle("←", act(() -> { if (t.web.canGoBack()) t.web.goBack(); })));
        row.addView(circle("→", act(() -> { if (t.web.canGoForward()) t.web.goForward(); })));
        row.addView(circle(isBm(t.url) ? "★" : "☆", act(this::toggleBm)));
        row.addView(circle("⬇", act(this::openDownloads)));
        row.addView(circle("⟳", act(() -> t.web.reload())));
        box.addView(row);

        item(box, "＋", "New tab", () -> newTab(HOME));
        item(box, "★", "Bookmarks", this::showBookmarks);
        item(box, "⬇", "Downloads", this::openDownloads);
        item(box, "⤴", "Share", () -> {
            Intent s = new Intent(Intent.ACTION_SEND);
            s.setType("text/plain");
            s.putExtra(Intent.EXTRA_TEXT, t.url);
            startActivity(Intent.createChooser(s, "Share"));
        });
        item(box, t.desktop ? "☑" : "☐", "Desktop site", () -> toggleDesktop(t));
        item(box, full ? "⤡" : "⛶", full ? "Exit full screen" : "Full screen", () -> setFull(!full));
        item(box, "ⓘ", "About", this::showAbout);

        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        int[] loc = new int[2];
        menuBtn.getLocationOnScreen(loc);
        int avail = getResources().getDisplayMetrics().heightPixels - loc[1] - dp(16);
        box.measure(View.MeasureSpec.makeMeasureSpec(dp(270), View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int hgt = Math.min(box.getMeasuredHeight(), avail);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFFF6F1E6);
        bg.setCornerRadius(dp(20));
        menuPw = new PopupWindow(sv, dp(270), hgt, true);
        menuPw.setBackgroundDrawable(bg);
        menuPw.setElevation(dp(8));
        menuPw.setOutsideTouchable(true);
        menuOpen = true;
        menuPw.setOnDismissListener(() -> menuOpen = false);
        menuPw.showAtLocation(root, Gravity.TOP | Gravity.END, dp(8), loc[1]);
    }

    private void toggleDesktop(Tab t) {
        t.desktop = !t.desktop;
        t.web.getSettings().setUserAgentString(t.desktop ? DESKTOP_UA : t.defaultUa);
        t.web.reload();
    }

    private void openDownloads() {
        try {
            startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS));
        } catch (Exception e) {
            Toast.makeText(this, "Downloads app not found", Toast.LENGTH_SHORT).show();
        }
    }

    // ---------- Bookmarks ----------
    private SharedPreferences sp() {
        return getSharedPreferences("lb", MODE_PRIVATE);
    }

    private boolean isBm(String u) {
        return !u.isEmpty() && sp().getStringSet("bm", new HashSet<String>()).contains(u);
    }

    private void toggleBm() {
        String u = tabs.get(cur).url;
        if (u.isEmpty()) return;
        Set<String> s = new HashSet<String>(sp().getStringSet("bm", new HashSet<String>()));
        boolean added = !s.remove(u);
        if (added) s.add(u);
        sp().edit().putStringSet("bm", s).apply();
        Toast.makeText(this, added ? "Bookmark added" : "Bookmark removed", Toast.LENGTH_SHORT).show();
    }

    private void showBookmarks() {
        Set<String> s = sp().getStringSet("bm", new HashSet<String>());
        final String[] a = s.toArray(new String[0]);
        if (a.length == 0) {
            Toast.makeText(this, "No bookmarks yet", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this).setTitle("Bookmarks")
                .setItems(a, (d, i) -> newTab(a[i])).show();
    }

    private void showAbout() {
        new AlertDialog.Builder(this)
                .setTitle("Lite Browser")
                .setMessage("A light, Chrome-style browser built on Android WebView.\n\n"
                        + "Creator: Mohammod Abdul Awal\n"
                        + "Student: Department of English, National University.")
                .setPositiveButton("OK", null)
                .show();
    }

    // ---------- Full screen ----------
    private void setFull(boolean on) {
        full = on;
        barsOn = !on;
        h.removeCallbacks(hideRun);
        applyBars();
        swExit.setVisibility(on ? View.VISIBLE : View.GONE);
        applySystemUi();
        if (on) Toast.makeText(this, "উপরের দিকে সোয়াইপ করলে বাটন দেখাবে (২ আঙুলে বা পেজের শেষে)", Toast.LENGTH_LONG).show();
    }

    private void applyBars() {
        int v = barsOn ? View.VISIBLE : View.GONE;
        toolbar.setVisibility(v);
        bottomBar.setVisibility(v);
    }

    private void showBars() {
        if (!full) return;
        barsOn = true;
        applyBars();
        h.removeCallbacks(hideRun);
        h.postDelayed(hideRun, 5000);
    }

    @SuppressWarnings("deprecation")
    private void applySystemUi() {
        View d = getWindow().getDecorView();
        if (full || customView != null) {
            d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        } else {
            getWindow().setStatusBarColor(Color.WHITE);
            getWindow().setNavigationBarColor(0xFFF6F7FB);
            d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                    | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
    }

    private void hideCustom() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
        applySystemUi();
    }

    // ---------- Helpers ----------
    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (customView != null) { hideCustom(); return; }
        if (switcher.getVisibility() == View.VISIBLE) { hideSwitcher(); return; }
        if (full && !barsOn) { showBars(); return; }
        Tab t = tabs.get(cur);
        if (t.web.canGoBack()) { t.web.goBack(); return; }
        if (full) { setFull(false); return; }
        if (tabs.size() > 1) { closeTab(cur); return; }
        super.onBackPressed();
    }

    private void hideKeyboard() {
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        im.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }
}
