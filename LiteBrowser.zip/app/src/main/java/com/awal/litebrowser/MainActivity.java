package com.awal.litebrowser;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity {

    static final String HOME = "https://www.google.com";

    static class Tab {
        WebView web;
        String title = "New tab";
        String url = "";
    }

    private final ArrayList<Tab> tabs = new ArrayList<>();
    private int cur = -1;
    private boolean full = false;
    private float swipeY0;

    private FrameLayout root, webBox, strip;
    private LinearLayout toolbar, switcher;
    private EditText urlBar;
    private TextView tabBtn, menuBtn, swExit, swTitle;
    private ProgressBar progress;
    private GridLayout grid;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        root = findViewById(R.id.root);
        webBox = findViewById(R.id.webBox);
        strip = findViewById(R.id.swipeStrip);
        toolbar = findViewById(R.id.toolbar);
        switcher = findViewById(R.id.switcher);
        urlBar = findViewById(R.id.urlBar);
        tabBtn = findViewById(R.id.tabBtn);
        menuBtn = findViewById(R.id.menuBtn);
        swExit = findViewById(R.id.swExit);
        swTitle = findViewById(R.id.swTitle);
        progress = findViewById(R.id.progress);
        grid = findViewById(R.id.grid);

        urlBar.setOnEditorActionListener((v, a, e) -> {
            go(urlBar.getText().toString());
            hideKeyboard();
            urlBar.clearFocus();
            return true;
        });
        tabBtn.setOnClickListener(v -> showSwitcher());
        menuBtn.setOnClickListener(this::showMenu);
        findViewById(R.id.swNew).setOnClickListener(v -> newTab(HOME));
        findViewById(R.id.swAbout).setOnClickListener(v -> showAbout());
        swExit.setOnClickListener(v -> {
            setFull(false);
            hideSwitcher();
        });
        strip.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                swipeY0 = e.getRawY();
            } else if (e.getAction() == MotionEvent.ACTION_UP) {
                if (swipeY0 - e.getRawY() > dp(40)) showSwitcher();
            }
            return true;
        });

        applySystemUi();
        Uri d = getIntent().getData();
        newTab(d != null ? d.toString() : HOME);
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        if (i.getData() != null) newTab(i.getData().toString());
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) applySystemUi();
    }

    @Override
    protected void onDestroy() {
        for (Tab t : tabs) t.web.destroy();
        super.onDestroy();
    }

    // ---------- Tabs ----------
    private WebView makeWeb(final Tab t) {
        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);

        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("http://") || u.startsWith("https://") || u.startsWith("about:")) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String u, Bitmap f) {
                t.url = u;
                if (isCur(t)) refreshBar();
            }

            @Override
            public void onPageFinished(WebView v, String u) {
                t.url = u;
                if (isCur(t)) refreshBar();
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                if (isCur(t)) {
                    progress.setProgress(p);
                    progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
                }
            }

            @Override
            public void onReceivedTitle(WebView v, String title) {
                t.title = title;
            }

            @Override
            public void onShowCustomView(View v, CustomViewCallback cb) {
                if (customView != null) {
                    cb.onCustomViewHidden();
                    return;
                }
                customView = v;
                customCb = cb;
                root.addView(v, new FrameLayout.LayoutParams(-1, -1));
                applySystemUi();
            }

            @Override
            public void onHideCustomView() {
                hideCustom();
            }
        });

        w.setDownloadListener((u, ua, cd, mime, len) -> {
            try {
                DownloadManager.Request r = new DownloadManager.Request(Uri.parse(u));
                r.setMimeType(mime);
                r.addRequestHeader("User-Agent", ua);
                String c = CookieManager.getInstance().getCookie(u);
                if (c != null) r.addRequestHeader("Cookie", c);
                String fn = URLUtil.guessFileName(u, cd, mime);
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fn);
                ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
                Toast.makeText(this, "Downloading: " + fn, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Download failed", Toast.LENGTH_SHORT).show();
            }
        });
        return w;
    }

    private boolean isCur(Tab t) {
        return cur >= 0 && cur < tabs.size() && tabs.get(cur) == t;
    }

    private void newTab(String url) {
        Tab t = new Tab();
        t.web = makeWeb(t);
        tabs.add(t);
        select(tabs.size() - 1);
        t.web.loadUrl(url);
        hideSwitcher();
    }

    // Each tab = its own WebView. Background tabs are paused and detached.
    private void select(int i) {
        if (cur >= 0 && cur < tabs.size()) {
            Tab o = tabs.get(cur);
            o.web.onPause();
            webBox.removeView(o.web);
        }
        cur = i;
        Tab t = tabs.get(i);
        webBox.addView(t.web, new FrameLayout.LayoutParams(-1, -1));
        t.web.onResume();
        urlBar.clearFocus();
        progress.setVisibility(View.GONE);
        refreshBar();
    }

    private void closeTab(int i) {
        Tab t = tabs.get(i);
        if (tabs.size() == 1) {
            t.web.loadUrl(HOME);
            hideSwitcher();
            return;
        }
        boolean wasCur = (i == cur);
        if (wasCur) {
            webBox.removeView(t.web);
            cur = -1;
        }
        tabs.remove(i);
        t.web.destroy();
        if (wasCur) select(Math.min(i, tabs.size() - 1));
        else if (i < cur) cur--;
        refreshBar();
        buildGrid();
    }

    private void refreshBar() {
        if (cur < 0 || cur >= tabs.size()) return;
        Tab t = tabs.get(cur);
        if (!urlBar.hasFocus()) urlBar.setText(t.url);
        tabBtn.setText(String.valueOf(tabs.size()));
    }

    private void go(String in) {
        String s = in.trim();
        if (s.isEmpty()) return;
        String u;
        if (s.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) {
            u = s;
        } else if (s.contains(" ") || !s.contains(".")) {
            u = "https://www.google.com/search?q=" + Uri.encode(s);
        } else {
            u = "https://" + s;
        }
        tabs.get(cur).web.loadUrl(u);
    }

    // ---------- Tab switcher ----------
    private void showSwitcher() {
        hideKeyboard();
        buildGrid();
        switcher.setVisibility(View.VISIBLE);
    }

    private void hideSwitcher() {
        switcher.setVisibility(View.GONE);
    }

    private void buildGrid() {
        grid.removeAllViews();
        swTitle.setText("Tabs (" + tabs.size() + ")");
        for (int i = 0; i < tabs.size(); i++) {
            final int idx = i;
            Tab t = tabs.get(i);

            LinearLayout c = new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL);
            c.setPadding(dp(12), dp(8), dp(12), dp(10));
            GradientDrawable g = new GradientDrawable();
            g.setColor(Color.WHITE);
            g.setCornerRadius(dp(16));
            if (i == cur) g.setStroke(dp(2), 0xFF1A73E8);
            c.setBackground(g);
            c.setOnClickListener(v -> {
                select(idx);
                hideSwitcher();
            });

            LinearLayout head = new LinearLayout(this);
            head.setGravity(Gravity.CENTER_VERTICAL);
            TextView title = new TextView(this);
            title.setText(t.title);
            title.setSingleLine(true);
            title.setEllipsize(android.text.TextUtils.TruncateAt.END);
            title.setTextColor(0xFF202124);
            title.setTextSize(14);
            head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
            TextView x = new TextView(this);
            x.setText("✕");
            x.setTextSize(16);
            x.setTextColor(0xFF5F6368);
            x.setPadding(dp(8), dp(4), dp(4), dp(4));
            x.setOnClickListener(v -> closeTab(idx));
            head.addView(x);
            c.addView(head);

            TextView u = new TextView(this);
            u.setText(t.url);
            u.setMaxLines(3);
            u.setEllipsize(android.text.TextUtils.TruncateAt.END);
            u.setTextColor(0xFF5F6368);
            u.setTextSize(12);
            u.setPadding(0, dp(8), 0, 0);
            c.addView(u);

            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                    GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
            lp.width = 0;
            lp.height = dp(130);
            lp.setMargins(dp(6), dp(6), dp(6), dp(6));
            grid.addView(c, lp);
        }
    }

    // ---------- Menu / About ----------
    private void showMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        Menu m = pm.getMenu();
        m.add(0, 1, 0, "New tab");
        m.add(0, 2, 1, "Back");
        m.add(0, 3, 2, "Forward");
        m.add(0, 4, 3, "Reload");
        m.add(0, 5, 4, "Full screen");
        m.add(0, 6, 5, "Share");
        m.add(0, 7, 6, "About");
        pm.setOnMenuItemClickListener(it -> {
            Tab t = tabs.get(cur);
            switch (it.getItemId()) {
                case 1: newTab(HOME); break;
                case 2: if (t.web.canGoBack()) t.web.goBack(); break;
                case 3: if (t.web.canGoForward()) t.web.goForward(); break;
                case 4: t.web.reload(); break;
                case 5: setFull(true); break;
                case 6:
                    Intent s = new Intent(Intent.ACTION_SEND);
                    s.setType("text/plain");
                    s.putExtra(Intent.EXTRA_TEXT, t.url);
                    startActivity(Intent.createChooser(s, "Share"));
                    break;
                case 7: showAbout(); break;
            }
            return true;
        });
        pm.show();
    }

    private void showAbout() {
        new AlertDialog.Builder(this)
                .setTitle("Lite Browser")
                .setMessage("A light, Chrome-style browser built on Android WebView.\n\n"
                        + "Creator: Mohammod Abdul Awal\n"
                        + "Student: Department of English, National University.")
                .setPositiveButton("OK", null)
                .show();
    }

    // ---------- Full screen ----------
    private void setFull(boolean on) {
        full = on;
        toolbar.setVisibility(on ? View.GONE : View.VISIBLE);
        strip.setVisibility(on ? View.VISIBLE : View.GONE);
        swExit.setVisibility(on ? View.VISIBLE : View.GONE);
        applySystemUi();
        if (on) Toast.makeText(this, "উপরের দিকে সোয়াইপ করলে ট্যাব দেখাবে", Toast.LENGTH_LONG).show();
    }

    @SuppressWarnings("deprecation")
    private void applySystemUi() {
        View d = getWindow().getDecorView();
        if (full || customView != null) {
            d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        } else {
            getWindow().setStatusBarColor(Color.WHITE);
            getWindow().setNavigationBarColor(Color.WHITE);
            d.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                    | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
    }

    private void hideCustom() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
        applySystemUi();
    }

    // ---------- Helpers ----------
    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (customView != null) { hideCustom(); return; }
        if (switcher.getVisibility() == View.VISIBLE) { hideSwitcher(); return; }
        Tab t = tabs.get(cur);
        if (t.web.canGoBack()) { t.web.goBack(); return; }
        if (full) { setFull(false); return; }
        if (tabs.size() > 1) { closeTab(cur); return; }
        super.onBackPressed();
    }

    private void hideKeyboard() {
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        im.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }
}
