# সহজ কিবোর্ড (Sohoj Keyboard)
হালকা Android কিবোর্ড: English + বাংলা (অভ্র-স্টাইল ফোনেটিক), ১৫টি থিম, নাম্বার রো, সিম্বল/ম্যাথ পেজ,
Copy/Cut/Paste/All, ◀ ▶ অ্যারো, ৩০ দিনের ক্লিপবোর্ড, ৪টা নেক্সট-ওয়ার্ড সাজেশন (টাইপ থেকে শেখে)।

## GitHub দিয়ে APK বানানো
1. GitHub-এ নতুন repository খুলুন।
2. এই ZIP-এর ভেতরের সব ফাইল (লুকানো `.github` ফোল্ডারসহ) আপলোড করুন।
   ফোনে হলে: পুরো ZIP ফাইলটাই আপলোড করুন + `build.yml` নিজে `.github/workflows/build.yml` নামে তৈরি করুন।
3. Actions ট্যাব -> Build APK -> সবুজ টিক এলে নিচে Artifacts থেকে `SohojKeyboard-APK` নামান।
4. ZIP খুলে `app-debug.apk` ইনস্টল করুন। অ্যাপ খুলে ২টা ধাপ করুন।
