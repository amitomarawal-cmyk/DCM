package com.sohoj.keyboard;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private SharedPreferences sp;
    private LinearLayout themeBox;

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String s, int sp2, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp2);
        t.setTextColor(0xFF222222);
        if (bold) t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        t.setPadding(0, dp(8), 0, dp(4));
        return t;
    }

    private Button btn(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("kb", Context.MODE_PRIVATE);

        ScrollView sv = new ScrollView(this);
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(24), dp(16), dp(32));
        sv.addView(c);

        c.addView(text(getString(R.string.app_name), 28, true));
        c.addView(text(getString(R.string.intro), 15, false));

        c.addView(btn(getString(R.string.step1), new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
            }
        }));
        c.addView(btn(getString(R.string.step2), new View.OnClickListener() {
            @Override public void onClick(View v) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.showInputMethodPicker();
            }
        }));

        EditText test = new EditText(this);
        test.setHint(getString(R.string.test_hint));
        c.addView(test);

        c.addView(text(getString(R.string.theme_title), 18, true));
        themeBox = new LinearLayout(this);
        themeBox.setOrientation(LinearLayout.VERTICAL);
        c.addView(themeBox);
        buildThemes();

        c.addView(btn(getString(R.string.guide_btn), new View.OnClickListener() {
            @Override public void onClick(View v) { startActivity(new Intent(MainActivity.this, GuideActivity.class)); }
        }));
        c.addView(btn(getString(R.string.reset_words), new View.OnClickListener() {
            @Override public void onClick(View v) {
                sp.edit().putLong("resetAt", System.currentTimeMillis()).apply();
                Toast.makeText(MainActivity.this, getString(R.string.done), Toast.LENGTH_SHORT).show();
            }
        }));
        c.addView(btn(getString(R.string.clear_clips), new View.OnClickListener() {
            @Override public void onClick(View v) {
                new ClipStore(MainActivity.this).clear();
                Toast.makeText(MainActivity.this, getString(R.string.done), Toast.LENGTH_SHORT).show();
            }
        }));
        setContentView(sv);
    }

    private void buildThemes() {
        themeBox.removeAllViews();
        int cur = sp.getInt("theme", 0);
        int per = 3;
        LinearLayout row = null;
        for (int i = 0; i < Themes.C.length; i++) {
            if (i % per == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                themeBox.addView(row);
            }
            final int idx = i;
            int[] t = Themes.C[i];
            TextView v = new TextView(this);
            v.setText(Themes.NAMES[i] + (i == cur ? "  ✔" : ""));
            v.setTextColor(t[2]);
            v.setGravity(Gravity.CENTER);
            v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            GradientDrawable g = new GradientDrawable();
            g.setColor(t[1]);
            g.setCornerRadius(dp(10));
            g.setStroke(dp(i == cur ? 4 : 2), i == cur ? t[4] : t[0]);
            v.setBackground(g);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(56), 1f);
            lp.setMargins(dp(4), dp(4), dp(4), dp(4));
            v.setLayoutParams(lp);
            v.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View x) {
                    sp.edit().putInt("theme", idx).apply();
                    buildThemes();
                }
            });
            row.addView(v);
        }
    }
}
