package com.sohoj.keyboard;

import android.app.Activity;
import android.os.Bundle;
import android.util.TypedValue;
import android.widget.ScrollView;
import android.widget.TextView;

public class GuideActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setTitle(getString(R.string.guide_title));
        float d = getResources().getDisplayMetrics().density;
        int p = (int) (16 * d);
        ScrollView sv = new ScrollView(this);
        TextView t = new TextView(this);
        t.setText(getString(R.string.guide));
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        t.setTextColor(0xFF222222);
        t.setLineSpacing(0, 1.3f);
        t.setTextIsSelectable(true);
        t.setPadding(p, (int) (28 * d), p, p * 2);
        sv.addView(t);
        setContentView(sv);
    }
}
