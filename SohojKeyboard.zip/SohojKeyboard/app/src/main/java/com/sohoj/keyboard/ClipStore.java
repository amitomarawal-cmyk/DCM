package com.sohoj.keyboard;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;

/** Clipboard history that keeps items for 30 days. */
public class ClipStore {
    public static final long TTL = 30L * 24 * 60 * 60 * 1000;

    public static class Item {
        public long t;
        public String s;
    }

    private final SharedPreferences sp;

    public ClipStore(Context c) {
        sp = c.getSharedPreferences("clips", Context.MODE_PRIVATE);
    }

    public ArrayList<Item> list() {
        ArrayList<Item> out = new ArrayList<>();
        long now = System.currentTimeMillis();
        boolean changed = false;
        try {
            JSONArray a = new JSONArray(sp.getString("d", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                long t = o.getLong("t");
                if (now - t > TTL) { changed = true; continue; }
                Item it = new Item();
                it.t = t;
                it.s = o.getString("s");
                out.add(it);
            }
        } catch (JSONException ignored) {}
        if (changed) save(out);
        return out;
    }

    private void save(ArrayList<Item> l) {
        JSONArray a = new JSONArray();
        for (Item it : l) {
            try {
                JSONObject o = new JSONObject();
                o.put("t", it.t);
                o.put("s", it.s);
                a.put(o);
            } catch (JSONException ignored) {}
        }
        sp.edit().putString("d", a.toString()).apply();
    }

    public void add(String s) {
        if (s == null || s.trim().isEmpty() || s.length() > 20000) return;
        ArrayList<Item> l = list();
        if (!l.isEmpty() && l.get(0).s.equals(s)) return;
        for (Iterator<Item> it = l.iterator(); it.hasNext(); ) {
            if (it.next().s.equals(s)) it.remove();
        }
        Item n = new Item();
        n.t = System.currentTimeMillis();
        n.s = s;
        l.add(0, n);
        while (l.size() > 300) l.remove(l.size() - 1);
        save(l);
    }

    public void remove(int idx) {
        ArrayList<Item> l = list();
        if (idx >= 0 && idx < l.size()) { l.remove(idx); save(l); }
    }

    public void clear() {
        sp.edit().remove("d").apply();
    }
}
