package com.sohoj.keyboard;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.RelativeSizeSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class KeyboardService extends InputMethodService {

    static final int M_LET = 0, M_SYM1 = 1, M_MATH = 2, M_MORE = 3;
    static final int ROW = 46;
    static final String[] BD = {"০", "১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯"};
    static final String[][] SYM = {
            {"@#$_&-+()/", "*\"':;!?~^`", "%=\\|[]."},
            {"+−×÷=≠≈±%‰", "<>≤≥(){}[]", "√∞π∑∫°²"},
            {"৳$€£¥₹¢©®™", "•←→↑↓∴∵।॥°", "αβγδθλΩ"}
    };

    private int mode = M_LET;
    private boolean bn = false;
    private int shift = 0; // 0 off, 1 once, 2 caps
    private final StringBuilder buf = new StringBuilder();
    private String prevWord = "";
    private boolean learning = true, composing = true;
    private int appliedTheme = -1;
    private int[] th = Themes.C[0];
    private boolean showingClip = false;
    private long lastReset = 0;

    private SharedPreferences sp;
    private WordStore words;
    private ClipStore clips;
    private ClipboardManager cm;
    private EditorInfo curEi;

    private LinearLayout root, keysBox, clipPanel;
    private final TextView[] sug = new TextView[4];
    private final ArrayList<TextView> letterKeys = new ArrayList<>();
    private TextView shiftKey;
    private final Handler h = new Handler(Looper.getMainLooper());

    private final Runnable delRep = new Runnable() {
        @Override public void run() {
            del();
            h.postDelayed(this, 55);
        }
    };

    private final ClipboardManager.OnPrimaryClipChangedListener clipL = new ClipboardManager.OnPrimaryClipChangedListener() {
        @Override public void onPrimaryClipChanged() { captureClip(); }
    };

    // ---------------------------------------------------------------- lifecycle

    @Override public void onCreate() {
        super.onCreate();
        sp = getSharedPreferences("kb", Context.MODE_PRIVATE);
        words = new WordStore(this);
        clips = new ClipStore(this);
        bn = sp.getBoolean("bn", false);
        lastReset = sp.getLong("resetAt", 0);
        cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.addPrimaryClipChangedListener(clipL);
    }

    @Override public void onDestroy() {
        if (cm != null) cm.removePrimaryClipChangedListener(clipL);
        words.save();
        super.onDestroy();
    }

    @Override public boolean onEvaluateFullscreenMode() { return false; }

    @Override public View onCreateInputView() { return build(); }

    @Override public void onStartInputView(EditorInfo ei, boolean restarting) {
        super.onStartInputView(ei, restarting);
        curEi = ei;
        if (theme() != appliedTheme) setInputView(onCreateInputView());

        long r = sp.getLong("resetAt", 0);
        if (r > lastReset) { words.clear(); lastReset = r; prevWord = ""; }

        int cls = ei.inputType & InputType.TYPE_MASK_CLASS;
        int var = ei.inputType & InputType.TYPE_MASK_VARIATION;
        boolean pw = (cls == InputType.TYPE_CLASS_TEXT && (var == InputType.TYPE_TEXT_VARIATION_PASSWORD
                || var == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                || var == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD))
                || (cls == InputType.TYPE_CLASS_NUMBER && var == InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        boolean numeric = cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE
                || cls == InputType.TYPE_CLASS_DATETIME;
        learning = !pw;
        composing = !pw;
        bn = sp.getBoolean("bn", false);
        if (pw || numeric) bn = false;
        mode = numeric ? M_SYM1 : M_LET;
        buf.setLength(0);
        prevWord = "";
        shift = 0;
        showClip(false);
        render();
        updateSug();
        captureClip();
    }

    @Override public void onFinishInput() {
        super.onFinishInput();
        buf.setLength(0);
        h.removeCallbacks(delRep);
        words.save();
    }

    @Override public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart, int newSelEnd,
                                            int candidatesStart, int candidatesEnd) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd);
        if (buf.length() > 0 && (newSelStart != candidatesEnd || newSelEnd != candidatesEnd)) {
            buf.setLength(0);
            InputConnection ic = getCurrentInputConnection();
            if (ic != null) ic.finishComposingText();
            updateSug();
        }
    }

    // ---------------------------------------------------------------- helpers

    private int theme() {
        return Math.max(0, Math.min(Themes.C.length - 1, sp.getInt("theme", 0)));
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static int blend(int a, int b, float f) {
        return Color.rgb((int) (Color.red(a) * (1 - f) + Color.red(b) * f),
                (int) (Color.green(a) * (1 - f) + Color.green(b) * f),
                (int) (Color.blue(a) * (1 - f) + Color.blue(b) * f));
    }

    private GradientDrawable rr(int c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(c);
        g.setCornerRadius(dp(7));
        return g;
    }

    private StateListDrawable bg(int c) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, rr(blend(c, th[4], 0.55f)));
        s.addState(new int[]{}, rr(c));
        return s;
    }

    private void hap(View v) {
        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    }

    private LinearLayout row(int heightDp) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(heightDp)));
        return r;
    }

    /** kind: 0 normal, 1 special, 2 accent */
    private TextView key(String label, float weight, int kind, final View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setGravity(Gravity.CENTER);
        t.setTextColor(kind == 2 ? th[0] : th[2]);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        t.setSingleLine(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, weight);
        lp.setMargins(dp(2), dp(3), dp(2), dp(3));
        t.setLayoutParams(lp);
        t.setBackground(bg(kind == 0 ? th[1] : kind == 1 ? th[3] : th[4]));
        t.setClickable(true);
        if (l != null) {
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { hap(v); l.onClick(v); }
            });
        }
        return t;
    }

    private TextView tool(String label, View.OnClickListener l) {
        TextView t = key(label, 1f, 1, l);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) t.getLayoutParams();
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        return t;
    }

    // ---------------------------------------------------------------- build UI

    private View build() {
        appliedTheme = theme();
        th = Themes.C[appliedTheme];
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(th[0]);
        root.setPadding(dp(2), dp(2), dp(2), dp(4));

        // suggestions
        LinearLayout sr = row(38);
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setGravity(Gravity.CENTER);
            t.setTextColor(th[2]);
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
            t.setSingleLine(true);
            t.setEllipsize(TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1f);
            lp.setMargins(dp(2), dp(2), dp(2), dp(2));
            t.setLayoutParams(lp);
            t.setBackground(bg(th[3]));
            t.setClickable(true);
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { hap(v); pickSuggestion(idx); }
            });
            sug[i] = t;
            sr.addView(t);
        }
        root.addView(sr);

        // toolbar
        LinearLayout tb = row(36);
        tb.addView(tool("📋", new View.OnClickListener() {
            @Override public void onClick(View v) { showClip(!showingClip); }
        }));
        tb.addView(tool("Copy", new View.OnClickListener() {
            @Override public void onClick(View v) { act(android.R.id.copy); }
        }));
        tb.addView(tool("Cut", new View.OnClickListener() {
            @Override public void onClick(View v) { act(android.R.id.cut); }
        }));
        tb.addView(tool("Paste", new View.OnClickListener() {
            @Override public void onClick(View v) { act(android.R.id.paste); }
        }));
        tb.addView(tool("All", new View.OnClickListener() {
            @Override public void onClick(View v) { act(android.R.id.selectAll); }
        }));
        tb.addView(tool("◀", new View.OnClickListener() {
            @Override public void onClick(View v) { arrow(KeyEvent.KEYCODE_DPAD_LEFT); }
        }));
        tb.addView(tool("▶", new View.OnClickListener() {
            @Override public void onClick(View v) { arrow(KeyEvent.KEYCODE_DPAD_RIGHT); }
        }));
        tb.addView(tool("⚙", new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent i = new Intent(KeyboardService.this, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            }
        }));
        root.addView(tb);

        keysBox = new LinearLayout(this);
        keysBox.setOrientation(LinearLayout.VERTICAL);
        keysBox.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(ROW * 5)));
        root.addView(keysBox);

        clipPanel = new LinearLayout(this);
        clipPanel.setOrientation(LinearLayout.VERTICAL);
        clipPanel.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(ROW * 5)));
        clipPanel.setVisibility(View.GONE);
        root.addView(clipPanel);

        showingClip = false;
        render();
        updateSug();
        return root;
    }

    private void render() {
        if (keysBox == null) return;
        keysBox.removeAllViews();
        letterKeys.clear();
        shiftKey = null;

        LinearLayout r0 = row(ROW);
        for (int i = 0; i < 10; i++) {
            final int n = i;
            r0.addView(key(bn ? BD[i] : String.valueOf(i), 1f, 0, new View.OnClickListener() {
                @Override public void onClick(View v) { typeDigit(n); }
            }));
        }
        keysBox.addView(r0);

        if (mode == M_LET) {
            String[] L = {"qwertyuiop", "asdfghjkl", "zxcvbnm"};
            LinearLayout r1 = row(ROW);
            for (int i = 0; i < L[0].length(); i++) r1.addView(letterKey(String.valueOf(L[0].charAt(i))));
            keysBox.addView(r1);

            LinearLayout r2 = row(ROW);
            r2.addView(spacer(0.5f));
            for (int i = 0; i < L[1].length(); i++) r2.addView(letterKey(String.valueOf(L[1].charAt(i))));
            r2.addView(spacer(0.5f));
            keysBox.addView(r2);

            LinearLayout r3 = row(ROW);
            shiftKey = key("⇧", 1.5f, 1, new View.OnClickListener() {
                @Override public void onClick(View v) { shift = (shift + 1) % 3; refreshLetters(); }
            });
            r3.addView(shiftKey);
            for (int i = 0; i < L[2].length(); i++) r3.addView(letterKey(String.valueOf(L[2].charAt(i))));
            r3.addView(delKey(1.5f));
            keysBox.addView(r3);
        } else {
            String[] S = SYM[mode - 1];
            for (int r = 0; r < 2; r++) {
                LinearLayout rw = row(ROW);
                for (int i = 0; i < S[r].length(); i++) rw.addView(symKey(String.valueOf(S[r].charAt(i))));
                keysBox.addView(rw);
            }
            LinearLayout rw = row(ROW);
            rw.addView(key(mode + "/3", 1.4f, 1, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    mode = (mode == M_MORE) ? M_SYM1 : mode + 1;
                    render();
                }
            }));
            for (int i = 0; i < S[2].length(); i++) rw.addView(symKey(String.valueOf(S[2].charAt(i))));
            rw.addView(delKey(1.4f));
            keysBox.addView(rw);
        }

        LinearLayout rb = row(ROW);
        rb.addView(key(mode == M_LET ? "?123" : "ABC", 1.4f, 1, new View.OnClickListener() {
            @Override public void onClick(View v) {
                mode = (mode == M_LET) ? M_SYM1 : M_LET;
                render();
            }
        }));
        rb.addView(key(bn ? "বা" : "EN", 1f, 1, new View.OnClickListener() {
            @Override public void onClick(View v) { toggleLang(); }
        }));
        rb.addView(key(",", 1f, 0, new View.OnClickListener() {
            @Override public void onClick(View v) { typePunct(","); }
        }));
        rb.addView(key(bn ? "বাংলা" : "English", 4f, 0, new View.OnClickListener() {
            @Override public void onClick(View v) { typeSpace(); }
        }));
        rb.addView(key(".", 1f, 0, new View.OnClickListener() {
            @Override public void onClick(View v) { typePunct(bn ? "।" : "."); }
        }));
        rb.addView(key("↵", 1.4f, 2, new View.OnClickListener() {
            @Override public void onClick(View v) { enter(); }
        }));
        keysBox.addView(rb);

        refreshLetters();
    }

    private View spacer(float w) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(0, -1, w));
        return v;
    }

    private TextView letterKey(final String c) {
        final TextView t = key(c, 1f, 0, null);
        t.setTag(c);
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                hap(v);
                typeLetter(shift > 0 ? c.toUpperCase(Locale.ROOT) : c);
                if (shift == 1) { shift = 0; refreshLetters(); }
            }
        });
        letterKeys.add(t);
        return t;
    }

    private TextView symKey(final String s) {
        TextView t = key(s, 1f, 0, new View.OnClickListener() {
            @Override public void onClick(View v) { typePunct(s); }
        });
        return t;
    }

    private TextView delKey(float w) {
        final TextView t = key("⌫", w, 1, null);
        t.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.setPressed(true);
                        hap(v);
                        del();
                        h.removeCallbacks(delRep);
                        h.postDelayed(delRep, 400);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.setPressed(false);
                        h.removeCallbacks(delRep);
                        return true;
                    default:
                        return true;
                }
            }
        });
        return t;
    }

    private void refreshLetters() {
        for (TextView t : letterKeys) {
            String base = (String) t.getTag();
            String l = shift > 0 ? base.toUpperCase(Locale.ROOT) : base;
            if (bn) {
                String hint = Avro.convert(l);
                SpannableString sp2 = new SpannableString(l + "\n" + hint);
                sp2.setSpan(new RelativeSizeSpan(0.6f), l.length() + 1, sp2.length(), 0);
                t.setSingleLine(false);
                t.setMaxLines(2);
                t.setText(sp2);
            } else {
                t.setText(l);
            }
        }
        if (shiftKey != null) {
            shiftKey.setText(shift == 0 ? "⇧" : shift == 1 ? "⬆" : "⇪");
            shiftKey.setBackground(bg(shift > 0 ? th[4] : th[3]));
            shiftKey.setTextColor(shift > 0 ? th[0] : th[2]);
        }
    }

    // ---------------------------------------------------------------- clipboard panel

    private void showClip(boolean on) {
        showingClip = on;
        if (keysBox == null || clipPanel == null) return;
        keysBox.setVisibility(on ? View.GONE : View.VISIBLE);
        clipPanel.setVisibility(on ? View.VISIBLE : View.GONE);
        if (on) fillClip();
    }

    private void fillClip() {
        clipPanel.removeAllViews();
        LinearLayout head = row(40);
        TextView title = new TextView(this);
        title.setText(getString(R.string.clip_title));
        title.setTextColor(th[2]);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(8), 0, 0, 0);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, -1, 2f));
        head.addView(title);
        head.addView(tool(getString(R.string.clear_all), new View.OnClickListener() {
            @Override public void onClick(View v) { clips.clear(); fillClip(); }
        }));
        head.addView(tool("ABC", new View.OnClickListener() {
            @Override public void onClick(View v) { showClip(false); }
        }));
        clipPanel.addView(head);

        ScrollView sv = new ScrollView(this);
        sv.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list);
        clipPanel.addView(sv);

        final ArrayList<ClipStore.Item> items = clips.list();
        if (items.isEmpty()) {
            TextView e = new TextView(this);
            e.setText(getString(R.string.clip_empty));
            e.setTextColor(th[2]);
            e.setGravity(Gravity.CENTER);
            e.setPadding(0, dp(30), 0, 0);
            list.addView(e);
            return;
        }
        for (int i = 0; i < items.size(); i++) {
            final int idx = i;
            final String text = items.get(i).s;
            LinearLayout rw = new LinearLayout(this);
            rw.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
            rp.setMargins(dp(3), dp(3), dp(3), 0);
            rw.setLayoutParams(rp);

            TextView t = new TextView(this);
            t.setText(text);
            t.setTextColor(th[2]);
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            t.setMaxLines(2);
            t.setEllipsize(TextUtils.TruncateAt.END);
            t.setPadding(dp(10), dp(8), dp(10), dp(8));
            t.setBackground(bg(th[1]));
            t.setClickable(true);
            t.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    hap(v);
                    InputConnection ic = getCurrentInputConnection();
                    if (ic != null) {
                        commitBuffer();
                        ic.commitText(text, 1);
                    }
                    showClip(false);
                }
            });
            rw.addView(t);

            TextView x = new TextView(this);
            x.setText("✕");
            x.setGravity(Gravity.CENTER);
            x.setTextColor(th[2]);
            x.setBackground(bg(th[3]));
            x.setClickable(true);
            LinearLayout.LayoutParams xp = new LinearLayout.LayoutParams(dp(42), -1);
            xp.setMargins(dp(3), 0, 0, 0);
            x.setLayoutParams(xp);
            x.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { clips.remove(idx); fillClip(); }
            });
            rw.addView(x);
            list.addView(rw);
        }
    }

    private void captureClip() {
        try {
            if (cm == null) return;
            ClipData d = cm.getPrimaryClip();
            if (d != null && d.getItemCount() > 0) {
                CharSequence t = d.getItemAt(0).coerceToText(this);
                if (t != null) clips.add(t.toString());
            }
        } catch (Exception ignored) {}
    }

    // ---------------------------------------------------------------- typing logic

    private String display() {
        return bn ? Avro.convert(buf.toString()) : buf.toString();
    }

    private void showComposing() {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) ic.setComposingText(display(), 1);
        updateSug();
    }

    private String commitBuffer() {
        if (buf.length() == 0) return "";
        String disp = display();
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) ic.finishComposingText();
        buf.setLength(0);
        learn(disp);
        return disp;
    }

    private static boolean wordOk(String x) {
        for (int i = 0; i < x.length(); i++) {
            char c = x.charAt(i);
            int ty = Character.getType(c);
            if (!(Character.isLetter(c) || c == '\''
                    || ty == Character.NON_SPACING_MARK || ty == Character.COMBINING_SPACING_MARK)) return false;
        }
        return true;
    }

    private void learn(String w) {
        if (!learning) return;
        String x = w.toLowerCase(Locale.ROOT);
        while (x.startsWith("'")) x = x.substring(1);
        while (x.endsWith("'")) x = x.substring(0, x.length() - 1);
        if (x.length() < 2 || !wordOk(x)) { prevWord = ""; return; }
        words.learn(prevWord, x);
        prevWord = x;
    }

    private void typeLetter(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (composing) {
            buf.append(s);
            showComposing();
        } else {
            ic.commitText(bn ? Avro.convert(s) : s, 1);
        }
    }

    private void typeDigit(int n) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        commitBuffer();
        ic.commitText(bn ? BD[n] : String.valueOf(n), 1);
        updateSug();
    }

    private void typePunct(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (composing && buf.length() > 0) {
            if (bn && (s.equals("^") || s.equals("`"))) { buf.append(s); showComposing(); return; }
            if (!bn && s.equals("'")) { buf.append(s); showComposing(); return; }
        }
        commitBuffer();
        ic.commitText(s, 1);
        if (".!?।".contains(s)) prevWord = "";
        updateSug();
    }

    private void typeSpace() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        commitBuffer();
        ic.commitText(" ", 1);
        updateSug();
    }

    private void del() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (buf.length() > 0) {
            buf.setLength(buf.length() - 1);
            if (buf.length() == 0) {
                ic.commitText("", 1);
                updateSug();
            } else {
                showComposing();
            }
            return;
        }
        CharSequence sel = ic.getSelectedText(0);
        if (sel != null && sel.length() > 0) ic.commitText("", 1);
        else sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
    }

    private void enter() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        commitBuffer();
        EditorInfo ei = curEi;
        boolean sent = false;
        if (ei != null) {
            boolean multi = (ei.inputType & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0;
            int a = ei.imeOptions & EditorInfo.IME_MASK_ACTION;
            boolean noAction = (ei.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0;
            if (!multi && !noAction && a != EditorInfo.IME_ACTION_NONE && a != EditorInfo.IME_ACTION_UNSPECIFIED) {
                ic.performEditorAction(a);
                sent = true;
            }
        }
        if (!sent) sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
        prevWord = "";
        updateSug();
    }

    private void toggleLang() {
        commitBuffer();
        bn = !bn;
        sp.edit().putBoolean("bn", bn).apply();
        mode = M_LET;
        shift = 0;
        render();
        updateSug();
    }

    private void act(int id) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        commitBuffer();
        ic.performContextMenuAction(id);
    }

    private void arrow(int code) {
        commitBuffer();
        sendDownUpKeyEvents(code);
    }

    // ---------------------------------------------------------------- suggestions

    private String fix(String w, String cur) {
        if (w.equals("i")) return "I";
        if (!bn && !cur.isEmpty() && !w.isEmpty() && Character.isUpperCase(cur.charAt(0))) {
            return Character.toUpperCase(w.charAt(0)) + w.substring(1);
        }
        return w;
    }

    private void updateSug() {
        if (sug[0] == null) return;
        String cur = buf.length() == 0 ? "" : display();
        List<String> l = new ArrayList<>();
        if (learning) {
            l = cur.isEmpty() ? words.next(prevWord, bn, 4) : words.complete(cur, bn, 4);
        }
        for (int i = 0; i < 4; i++) {
            sug[i].setText(i < l.size() ? fix(l.get(i), cur) : "");
        }
    }

    private void pickSuggestion(int i) {
        String s = sug[i].getText().toString();
        InputConnection ic = getCurrentInputConnection();
        if (s.isEmpty() || ic == null) return;
        ic.commitText(s + " ", 1);
        buf.setLength(0);
        learn(s);
        updateSug();
    }
}
