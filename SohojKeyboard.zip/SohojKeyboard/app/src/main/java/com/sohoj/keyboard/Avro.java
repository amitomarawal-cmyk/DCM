package com.sohoj.keyboard;

import java.util.HashMap;

/** Simple Avro-style phonetic converter: English letters -> Bengali. */
public final class Avro {
    private static final HashMap<String, String> CONS = new HashMap<>();
    private static final HashMap<String, String[]> VOW = new HashMap<>();
    private static final HashMap<String, String> MARK = new HashMap<>();
    private static final String HASANTA = "\u09CD";

    private static void cons(String k, String v) { CONS.put(k, v); }
    private static void vow(String k, String a, String b) { VOW.put(k, new String[]{a, b}); }

    static {
        cons("kkh", "ক্ষ"); cons("GG", "জ্ঞ");
        cons("kh", "খ"); cons("gh", "ঘ"); cons("Ng", "ঙ"); cons("ch", "ছ"); cons("jh", "ঝ"); cons("NG", "ঞ");
        cons("Th", "ঠ"); cons("Dh", "ঢ"); cons("th", "থ"); cons("dh", "ধ"); cons("ph", "ফ"); cons("bh", "ভ");
        cons("sh", "শ"); cons("Sh", "ষ"); cons("Rh", "ঢ়");
        cons("k", "ক"); cons("g", "গ"); cons("c", "চ"); cons("j", "জ"); cons("T", "ট"); cons("D", "ড");
        cons("N", "ণ"); cons("t", "ত"); cons("d", "দ"); cons("n", "ন"); cons("p", "প"); cons("f", "ফ");
        cons("b", "ব"); cons("v", "ভ"); cons("m", "ম"); cons("z", "য"); cons("r", "র"); cons("l", "ল");
        cons("s", "স"); cons("S", "শ"); cons("h", "হ"); cons("R", "ড়"); cons("y", "য়"); cons("Y", "য়");
        cons("x", "ক্স"); cons("q", "ক");

        vow("a", "আ", "া"); vow("i", "ই", "ি"); vow("I", "ঈ", "ী"); vow("u", "উ", "ু"); vow("U", "ঊ", "ূ");
        vow("e", "এ", "ে"); vow("OI", "ঐ", "ৈ"); vow("O", "ও", "ো"); vow("OU", "ঔ", "ৌ");
        vow("rri", "ঋ", "ৃ"); vow("w", "ও", "ও");

        MARK.put("ng", "ং"); MARK.put("H", "ঃ"); MARK.put("^", "ঁ"); MARK.put("t`", "ৎ");
    }

    private Avro() {}

    private static boolean known(String t) {
        return t.equals("o") || VOW.containsKey(t) || MARK.containsKey(t) || CONS.containsKey(t);
    }

    public static String convert(String s) {
        StringBuilder o = new StringBuilder();
        int st = 0; // 0 = start/vowel, 1 = consonant (inherent vowel), 2 = consonant finished
        int i = 0, n = s.length();
        while (i < n) {
            String tok = null;
            for (int l = Math.min(3, n - i); l >= 1; l--) {
                String t = s.substring(i, i + l);
                if (known(t)) { tok = t; break; }
            }
            if (tok == null) {
                String lo = s.substring(i, i + 1).toLowerCase(java.util.Locale.ROOT);
                if (known(lo)) tok = lo;
            }
            if (tok == null) { o.append(s.charAt(i)); st = 0; i++; continue; }
            i += tok.length();

            if (tok.equals("o")) {
                if (st == 1) st = 2; else { o.append("অ"); st = 0; }
            } else if (VOW.containsKey(tok)) {
                String[] x = VOW.get(tok);
                if (st == 1) { o.append(x[1]); st = 2; } else { o.append(x[0]); st = 0; }
            } else if (MARK.containsKey(tok)) {
                o.append(MARK.get(tok)); st = 2;
            } else {
                String val = CONS.get(tok);
                if (st == 1) {
                    o.append(HASANTA);
                    if (tok.equals("y") || tok.equals("Y")) val = "য"; // য-ফলা
                }
                o.append(val); st = 1;
            }
        }
        return o.toString();
    }
}
