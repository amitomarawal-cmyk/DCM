package com.sohoj.keyboard;

import android.content.Context;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Learns words and word pairs from what the user types. Stored in app-private files. */
public class WordStore {
    private final File fu, fb;
    private final HashMap<String, Integer> uni = new HashMap<>();
    private final HashMap<String, Integer> bi = new HashMap<>();
    private int dirty = 0;

    public WordStore(Context c) {
        fu = new File(c.getFilesDir(), "uni.txt");
        fb = new File(c.getFilesDir(), "bi.txt");
        read(fu, uni);
        read(fb, bi);
        if (uni.isEmpty()) seed();
    }

    private static void read(File f, HashMap<String, Integer> m) {
        if (!f.exists()) return;
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), "UTF-8"))) {
            String line;
            while ((line = r.readLine()) != null) {
                int p = line.lastIndexOf('\t');
                if (p <= 0) continue;
                try { m.put(line.substring(0, p), Integer.parseInt(line.substring(p + 1))); }
                catch (NumberFormatException ignored) {}
            }
        } catch (IOException ignored) {}
    }

    private static void write(File f, HashMap<String, Integer> m) {
        try (BufferedWriter w = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(f), "UTF-8"))) {
            for (Map.Entry<String, Integer> e : m.entrySet()) {
                w.write(e.getKey());
                w.write('\t');
                w.write(String.valueOf(e.getValue()));
                w.write('\n');
            }
        } catch (IOException ignored) {}
    }

    private void seed() {
        String[] en = {"the", "i", "you", "to", "and", "a", "is", "in", "it", "of", "for", "that", "this",
                "hello", "thanks", "please", "how", "are", "what", "good", "morning", "okay", "yes", "no",
                "where", "when", "will", "have", "with", "not"};
        String[] bn = {"আমি", "তুমি", "আপনি", "কি", "কী", "কেমন", "আছো", "আছেন", "ভালো", "আর", "না",
                "হ্যাঁ", "ধন্যবাদ", "আজ", "কাল", "এখন", "কোথায়", "কখন", "আসসালামু", "আলাইকুম", "শুভ",
                "সকাল", "রাত", "বাংলা", "বাংলাদেশ", "ঠিক", "আছে", "তোমাকে", "ভালোবাসি", "কাজ"};
        for (int i = 0; i < en.length; i++) uni.put(en[i], 40 - i);
        for (int i = 0; i < bn.length; i++) uni.put(bn[i], 40 - i);
    }

    public void learn(String prev, String w) {
        uni.merge(w, 1, Integer::sum);
        if (prev != null && !prev.isEmpty()) bi.merge(prev + "\t" + w, 1, Integer::sum);
        if (uni.size() > 8000) prune(uni);
        if (bi.size() > 20000) prune(bi);
        if (++dirty >= 10) save();
    }

    private static void prune(HashMap<String, Integer> m) {
        m.entrySet().removeIf(e -> e.getValue() <= 1);
    }

    public void save() {
        if (dirty == 0) return;
        dirty = 0;
        write(fu, uni);
        write(fb, bi);
    }

    public void clear() {
        uni.clear();
        bi.clear();
        seed();
        dirty = 1;
        save();
        fb.delete();
    }

    static boolean isBn(String w) {
        if (w.isEmpty()) return false;
        char c = w.charAt(0);
        return c >= 0x0980 && c <= 0x09FF;
    }

    public List<String> complete(String prefix, boolean bn, int n) {
        String p = prefix.toLowerCase(Locale.ROOT);
        ArrayList<Map.Entry<String, Integer>> m = new ArrayList<>();
        for (Map.Entry<String, Integer> e : uni.entrySet()) {
            String k = e.getKey();
            if (k.length() > p.length() && k.startsWith(p) && isBn(k) == bn) m.add(e);
        }
        Collections.sort(m, (a, b) -> b.getValue() - a.getValue());
        ArrayList<String> out = new ArrayList<>();
        for (int i = 0; i < m.size() && out.size() < n; i++) out.add(m.get(i).getKey());
        return out;
    }

    public List<String> next(String prev, boolean bn, int n) {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        if (prev != null && !prev.isEmpty()) {
            String pre = prev + "\t";
            ArrayList<Map.Entry<String, Integer>> m = new ArrayList<>();
            for (Map.Entry<String, Integer> e : bi.entrySet()) {
                String k = e.getKey();
                if (k.startsWith(pre) && isBn(k.substring(pre.length())) == bn) m.add(e);
            }
            Collections.sort(m, (a, b) -> b.getValue() - a.getValue());
            for (int i = 0; i < m.size() && out.size() < n; i++) out.add(m.get(i).getKey().substring(pre.length()));
        }
        if (out.size() < n) {
            ArrayList<Map.Entry<String, Integer>> m = new ArrayList<>();
            for (Map.Entry<String, Integer> e : uni.entrySet()) if (isBn(e.getKey()) == bn) m.add(e);
            Collections.sort(m, (a, b) -> b.getValue() - a.getValue());
            for (int i = 0; i < m.size() && out.size() < n; i++) out.add(m.get(i).getKey());
        }
        return new ArrayList<>(out);
    }
}
