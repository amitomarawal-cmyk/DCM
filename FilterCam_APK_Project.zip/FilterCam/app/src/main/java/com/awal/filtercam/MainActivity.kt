package com.awal.filtercam

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Rational
import android.util.Size
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.UseCaseGroup
import androidx.camera.core.ViewPort
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.RgbMatrix
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.awal.filtercam.databinding.ActivityMainBinding
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

@androidx.annotation.OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val filters = Filters.all
    private val bgExecutor = Executors.newSingleThreadExecutor()

    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null

    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var videoMode = false
    private var gridOn = true          // ডিফল্টভাবে Rule of Thirds চালু
    private var filterIndex = 0

    // ফ্ল্যাশ
    private val flashModes = listOf(
        ImageCapture.FLASH_MODE_OFF, ImageCapture.FLASH_MODE_ON, ImageCapture.FLASH_MODE_AUTO
    )
    private val flashLabels = listOf("⚡ OFF", "⚡ ON", "⚡ AUTO")
    private var flashIdx = 0

    // অনুপাত (portrait)
    private val ratios = listOf(Pair(3, 4), Pair(9, 16), Pair(1, 1))
    private val ratioLabels = listOf("3:4", "9:16", "1:1")
    private var ratioIdx = 0

    // রেজুলেশন
    private val resLabels = listOf("MAX", "FHD", "HD", "SD")
    private val photoSizes = listOf(
        Size(4032, 3024), Size(1920, 1440), Size(1280, 960), Size(640, 480)
    )
    private val videoQualities = listOf(Quality.UHD, Quality.FHD, Quality.HD, Quality.SD)
    private var resIdx = 0

    private lateinit var filterAdapter: FilterAdapter

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (hasPerm(Manifest.permission.CAMERA)) {
                startCamera()
            } else {
                toast("ক্যামেরার পারমিশন ছাড়া অ্যাপ চলবে না 😅")
                finish()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        b.previewView.scaleType = PreviewView.ScaleType.FILL_CENTER
        b.previewView.previewStreamState.observe(this) { state ->
            if (state == PreviewView.StreamState.STREAMING) applyPreviewFilter()
        }

        setupFilterList()
        setupTouch()
        setupButtons()
        applyRatioLayout()
        refreshUi()

        if (hasPerm(Manifest.permission.CAMERA)) {
            startCamera()
        } else {
            permLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        bgExecutor.shutdown()
    }

    // ---------------------------------------------------------------- UI setup

    private fun setupButtons() {
        b.btnFlash.setOnClickListener {
            flashIdx = (flashIdx + 1) % flashModes.size
            imageCapture?.flashMode = flashModes[flashIdx]
            camera?.cameraControl?.enableTorch(videoMode && flashIdx == 1)
            refreshUi()
        }
        b.btnRatio.setOnClickListener {
            ratioIdx = (ratioIdx + 1) % ratios.size
            applyRatioLayout()
            refreshUi()
            bindCamera()
        }
        b.btnRes.setOnClickListener {
            resIdx = (resIdx + 1) % resLabels.size
            refreshUi()
            bindCamera()
        }
        b.btnGrid.setOnClickListener {
            gridOn = !gridOn
            refreshUi()
        }
        b.btnAbout.setOnClickListener { showAbout() }
        b.btnSwitch.setOnClickListener {
            lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
                CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
            bindCamera()
        }
        b.modePhoto.setOnClickListener { setVideoMode(false) }
        b.modeVideo.setOnClickListener { setVideoMode(true) }
        b.btnShutter.setOnClickListener {
            if (videoMode) toggleRecording() else takePhoto()
        }
    }

    private fun setVideoMode(video: Boolean) {
        if (recording != null || videoMode == video) return
        videoMode = video
        refreshUi()
        bindCamera()
    }

    private fun refreshUi() {
        b.btnFlash.text = flashLabels[flashIdx]
        b.btnRatio.text = ratioLabels[ratioIdx]
        b.btnRes.text = resLabels[resIdx]
        b.gridOverlay.visibility = if (gridOn) View.VISIBLE else View.INVISIBLE
        b.btnGrid.setTextColor(if (gridOn) Color.parseColor("#FFC107") else Color.WHITE)
        b.modePhoto.setTextColor(if (!videoMode) Color.parseColor("#FFC107") else Color.WHITE)
        b.modeVideo.setTextColor(if (videoMode) Color.parseColor("#FFC107") else Color.WHITE)
        b.filterName.text = filters[filterIndex].name
        updateShutter()
    }

    private fun updateShutter() {
        b.btnShutter.setBackgroundResource(
            when {
                recording != null -> R.drawable.shutter_rec
                videoMode -> R.drawable.shutter_video
                else -> R.drawable.shutter_photo
            }
        )
    }

    private fun applyRatioLayout() {
        val (w, h) = ratios[ratioIdx]
        val lp = b.previewContainer.layoutParams as ConstraintLayout.LayoutParams
        lp.dimensionRatio = "H,$w:$h"
        b.previewContainer.layoutParams = lp
    }

    private fun setControlsEnabled(enabled: Boolean) {
        val a = if (enabled) 1f else 0.35f
        listOf(
            b.btnRatio, b.btnRes, b.btnSwitch, b.modePhoto, b.modeVideo, b.filterList
        ).forEach {
            it.isEnabled = enabled
            it.alpha = a
        }
    }

    private fun showAbout() {
        AlertDialog.Builder(this)
            .setTitle("FilterCam 📸")
            .setMessage(
                "50+ Professional Filters\nPhoto & Video • Rule of Thirds • Pinch Zoom • Tap Focus\n\n" +
                        "Creator: Mohammod Abdul Awal\n" +
                        "Student: Department of English, National University."
            )
            .setPositiveButton("OK", null)
            .show()
    }

    // ---------------------------------------------------------------- Filters

    private fun setupFilterList() {
        filterAdapter = FilterAdapter()
        b.filterList.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        b.filterList.adapter = filterAdapter
    }

    private fun selectFilter(i: Int) {
        if (recording != null || i < 0 || i == filterIndex) return
        val old = filterIndex
        filterIndex = i
        filterAdapter.notifyItemChanged(old)
        filterAdapter.notifyItemChanged(i)
        b.filterList.smoothScrollToPosition(i)
        b.filterName.text = filters[i].name
        applyPreviewFilter()
    }

    private fun applyPreviewFilter() {
        val f = filters[filterIndex]
        val paint: Paint? = if (f.isIdentity) null else Paint().apply {
            colorFilter = ColorMatrixColorFilter(ColorMatrix(f.androidMatrix))
        }
        val tv = findTextureView(b.previewView)
        if (tv != null) {
            tv.setLayerPaint(paint)
        } else {
            b.previewView.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
        }
    }

    private fun findTextureView(v: View): TextureView? {
        if (v is TextureView) return v
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) {
                findTextureView(v.getChildAt(i))?.let { return it }
            }
        }
        return null
    }

    private inner class FilterAdapter : RecyclerView.Adapter<FilterAdapter.VH>() {
        inner class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val tv = TextView(parent.context).apply {
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(dp(4), dp(8), dp(4), dp(8)) }
                setPadding(dp(14), dp(6), dp(14), dp(6))
                textSize = 13f
                gravity = Gravity.CENTER
            }
            return VH(tv)
        }

        override fun getItemCount() = filters.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val sel = position == filterIndex
            holder.tv.text = filters[position].name
            holder.tv.setTextColor(if (sel) Color.BLACK else Color.WHITE)
            holder.tv.setBackgroundResource(if (sel) R.drawable.chip_selected else R.drawable.chip_normal)
            holder.tv.setOnClickListener { selectFilter(holder.bindingAdapterPosition) }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------------------------------------------------------------- Touch: tap focus + pinch zoom

    private fun setupTouch() {
        val scaleDetector = ScaleGestureDetector(this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    val cam = camera ?: return true
                    val zoom = cam.cameraInfo.zoomState.value ?: return true
                    cam.cameraControl.setZoomRatio(zoom.zoomRatio * detector.scaleFactor)
                    return true
                }
            })
        val tapDetector = GestureDetector(this,
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onDown(e: MotionEvent) = true
                override fun onSingleTapUp(e: MotionEvent): Boolean {
                    focusAt(e.x, e.y)
                    return true
                }
            })
        b.previewView.setOnTouchListener { _, ev ->
            scaleDetector.onTouchEvent(ev)
            if (!scaleDetector.isInProgress) tapDetector.onTouchEvent(ev)
            true
        }
    }

    private fun focusAt(x: Float, y: Float) {
        val cam = camera ?: return
        val point = b.previewView.meteringPointFactory.createPoint(x, y)
        val action = FocusMeteringAction.Builder(
            point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
        ).setAutoCancelDuration(3, TimeUnit.SECONDS).build()
        cam.cameraControl.startFocusAndMetering(action)

        val ring = b.focusRing
        ring.animate().cancel()
        ring.x = x - ring.width / 2f
        ring.y = y - ring.height / 2f
        ring.scaleX = 1.4f
        ring.scaleY = 1.4f
        ring.alpha = 1f
        ring.visibility = View.VISIBLE
        ring.animate().scaleX(1f).scaleY(1f).setDuration(200).withEndAction {
            ring.animate().alpha(0f).setStartDelay(800).setDuration(300).withEndAction {
                ring.visibility = View.GONE
                ring.alpha = 1f
            }.start()
        }.start()
    }

    // ---------------------------------------------------------------- Camera

    private fun hasPerm(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            cameraProvider = future.get()
            bindCamera()
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindCamera() {
        val provider = cameraProvider ?: return
        provider.unbindAll()

        var selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
        val ok = try { provider.hasCamera(selector) } catch (e: Exception) { false }
        if (!ok) {
            lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
                CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
            selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
        }

        val aspect = if (ratioIdx == 1)
            AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
        else AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY

        val previewSelector = ResolutionSelector.Builder()
            .setAspectRatioStrategy(aspect)
            .build()

        val resStrategy = if (resIdx == 0) ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY
        else ResolutionStrategy(
            photoSizes[resIdx], ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
        )
        val photoSelector = ResolutionSelector.Builder()
            .setAspectRatioStrategy(aspect)
            .setResolutionStrategy(resStrategy)
            .build()

        val preview = Preview.Builder().setResolutionSelector(previewSelector).build()
            .also { it.setSurfaceProvider(b.previewView.surfaceProvider) }

        val (rw, rh) = ratios[ratioIdx]
        val rotation = b.previewView.display?.rotation ?: Surface.ROTATION_0
        val viewPort = ViewPort.Builder(Rational(rw, rh), rotation)
            .setScaleType(ViewPort.FILL_CENTER)
            .build()

        val group = UseCaseGroup.Builder().setViewPort(viewPort).addUseCase(preview)

        if (videoMode) {
            val q = videoQualities[resIdx]
            val recorder = Recorder.Builder()
                .setQualitySelector(
                    QualitySelector.from(q, FallbackStrategy.lowerQualityOrHigherThan(q))
                ).build()
            videoCapture = VideoCapture.withOutput(recorder)
            imageCapture = null
            group.addUseCase(videoCapture!!)
        } else {
            imageCapture = ImageCapture.Builder()
                .setResolutionSelector(photoSelector)
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setFlashMode(flashModes[flashIdx])
                .build()
            videoCapture = null
            group.addUseCase(imageCapture!!)
        }

        try {
            camera = provider.bindToLifecycle(this, selector, group.build())
            camera?.cameraControl?.enableTorch(videoMode && flashIdx == 1)
            b.btnFlash.alpha = if (camera?.cameraInfo?.hasFlashUnit() == true) 1f else 0.35f
        } catch (e: Exception) {
            toast("ক্যামেরা চালু করা যায়নি: ${e.message}")
        }
        b.previewView.post { applyPreviewFilter() }
    }

    // ---------------------------------------------------------------- Photo

    private fun takePhoto() {
        val ic = imageCapture ?: return
        val f = filters[filterIndex]
        ic.takePicture(bgExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    processPhoto(image, f)
                } catch (e: Throwable) {
                    toast("ছবি সেভ করা যায়নি: ${e.message}")
                } finally {
                    image.close()
                }
            }

            override fun onError(exception: ImageCaptureException) {
                toast("ছবি তোলা যায়নি: ${exception.message}")
            }
        })
    }

    private fun processPhoto(image: ImageProxy, f: FilterDef) {
        val rot = image.imageInfo.rotationDegrees
        val crop = image.cropRect
        var src = image.toBitmap()

        // ViewPort অনুযায়ী ক্রপ (যদি আগে থেকে না হয়ে থাকে)
        if (crop.width() > 0 && crop.height() > 0 &&
            crop.right <= src.width && crop.bottom <= src.height &&
            (crop.width() != src.width || crop.height() != src.height)
        ) {
            val cropped = Bitmap.createBitmap(src, crop.left, crop.top, crop.width(), crop.height())
            src.recycle()
            src = cropped
        }

        val m = Matrix()
        m.postRotate(rot.toFloat())
        val rect = RectF(0f, 0f, src.width.toFloat(), src.height.toFloat())
        m.mapRect(rect)
        m.postTranslate(-rect.left, -rect.top)

        val out = Bitmap.createBitmap(
            rect.width().toInt(), rect.height().toInt(), Bitmap.Config.ARGB_8888
        )
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        if (!f.isIdentity) paint.colorFilter = ColorMatrixColorFilter(ColorMatrix(f.androidMatrix))
        Canvas(out).drawBitmap(src, m, paint)
        src.recycle()

        val name = "FilterCam_${stamp()}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FilterCam")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            out.recycle()
            toast("গ্যালারিতে সেভ করা যায়নি")
            return
        }
        contentResolver.openOutputStream(uri)?.use { out.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        out.recycle()
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        contentResolver.update(uri, values, null, null)
        toast("ছবি গ্যালারিতে সেভ হয়েছে ✅")
    }

    // ---------------------------------------------------------------- Video

    private fun toggleRecording() {
        recording?.let {
            it.stop()
            return
        }
        val vc = videoCapture ?: return
        val f = filters[filterIndex]
        val raw = File(cacheDir, "raw_${stamp()}.mp4")
        val options = FileOutputOptions.Builder(raw).build()
        var pending = vc.output.prepareRecording(this, options)
        if (hasPerm(Manifest.permission.RECORD_AUDIO)) pending = pending.withAudioEnabled()

        recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
            when (event) {
                is VideoRecordEvent.Start -> {
                    b.recordTimer.visibility = View.VISIBLE
                    b.recordTimer.text = "● 00:00"
                    setControlsEnabled(false)
                    updateShutter()
                }
                is VideoRecordEvent.Status -> {
                    val s = event.recordingStats.recordedDurationNanos / 1_000_000_000L
                    b.recordTimer.text = String.format(Locale.US, "● %02d:%02d", s / 60, s % 60)
                }
                is VideoRecordEvent.Finalize -> {
                    recording = null
                    b.recordTimer.visibility = View.GONE
                    setControlsEnabled(true)
                    updateShutter()
                    if (event.hasError() && !raw.exists()) {
                        toast("ভিডিও রেকর্ড হয়নি 😢")
                    } else if (f.isIdentity) {
                        saveVideoAsync(raw)
                    } else {
                        applyFilterToVideo(raw, f)
                    }
                }
                else -> {}
            }
        }
    }

    private fun applyFilterToVideo(input: File, f: FilterDef) {
        val out = File(cacheDir, "flt_${stamp()}.mp4")
        val matrix = f.rgbMatrix
        val rgb = RgbMatrix { _, _ -> matrix }
        val effects = Effects(listOf<AudioProcessor>(), listOf<Effect>(rgb))
        val item = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(input)))
            .setEffects(effects)
            .build()

        b.processing.visibility = View.VISIBLE
        val transformer = Transformer.Builder(this)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    b.processing.visibility = View.GONE
                    input.delete()
                    saveVideoAsync(out)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    b.processing.visibility = View.GONE
                    toast("ফিল্টার বসানো যায়নি, অরিজিনাল ভিডিও সেভ হচ্ছে")
                    out.delete()
                    saveVideoAsync(input)
                }
            })
            .build()
        transformer.start(item, out.absolutePath)
    }

    private fun saveVideoAsync(file: File) {
        bgExecutor.execute {
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "FilterCam_${stamp()}.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/FilterCam")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                if (uri == null) {
                    toast("গ্যালারিতে সেভ করা যায়নি")
                    return@execute
                }
                contentResolver.openOutputStream(uri)?.use { os ->
                    file.inputStream().use { it.copyTo(os) }
                }
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
                toast("ভিডিও গ্যালারিতে সেভ হয়েছে ✅")
            } catch (e: Throwable) {
                toast("ভিডিও সেভ করা যায়নি: ${e.message}")
            } finally {
                file.delete()
            }
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun stamp(): String =
        SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun toast(msg: String) {
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    }
}
