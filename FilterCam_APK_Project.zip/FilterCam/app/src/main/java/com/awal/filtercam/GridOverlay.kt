package com.awal.filtercam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

/** Rule of Thirds গ্রিড (৩x৩) */
class GridOverlay @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val density = resources.displayMetrics.density
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xB3FFFFFF.toInt()
        strokeWidth = 1.2f * density
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFC107.toInt()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        for (i in 1..2) {
            canvas.drawLine(w * i / 3f, 0f, w * i / 3f, h, linePaint)
            canvas.drawLine(0f, h * i / 3f, w, h * i / 3f, linePaint)
        }
        for (i in 1..2) for (j in 1..2) {
            canvas.drawCircle(w * i / 3f, h * j / 3f, 3f * density, dotPaint)
        }
    }
}
