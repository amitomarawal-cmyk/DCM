package com.awal.filtercam

/**
 * একটা ফিল্টার = কয়েকটা সংখ্যার রেসিপি।
 * sat = রঙের ঝাঁজ, con = কনট্রাস্ট, bri = উজ্জ্বলতা,
 * r/g/b = লাল/সবুজ/নীল এর পরিমাণ, ro/go/bo = অতিরিক্ত রঙের ছোঁয়া
 */
class FilterDef(
    val name: String,
    sat: Float = 1f,
    con: Float = 1f,
    bri: Float = 0f,
    r: Float = 1f,
    g: Float = 1f,
    b: Float = 1f,
    ro: Float = 0f,
    go: Float = 0f,
    bo: Float = 0f
) {
    /** Android ColorMatrix (4x5, row-major, offset 0..255) — ছবি ও লাইভ প্রিভিউয়ের জন্য */
    val androidMatrix: FloatArray

    /** 4x4 column-major matrix — ভিডিওর জন্য (Media3 RgbMatrix) */
    val rgbMatrix: FloatArray

    val isIdentity: Boolean = name == "Normal"

    init {
        val lr = 0.213f
        val lg = 0.715f
        val lb = 0.072f
        val s = arrayOf(
            floatArrayOf((1 - sat) * lr + sat, (1 - sat) * lg, (1 - sat) * lb),
            floatArrayOf((1 - sat) * lr, (1 - sat) * lg + sat, (1 - sat) * lb),
            floatArrayOf((1 - sat) * lr, (1 - sat) * lg, (1 - sat) * lb + sat)
        )
        val gains = floatArrayOf(r, g, b)
        val extra = floatArrayOf(ro, go, bo)
        val m = Array(3) { FloatArray(3) }
        val off = FloatArray(3)
        for (i in 0..2) {
            for (j in 0..2) m[i][j] = gains[i] * con * s[i][j]
            off[i] = gains[i] * 0.5f * (1f - con) + bri + extra[i]
        }
        androidMatrix = floatArrayOf(
            m[0][0], m[0][1], m[0][2], 0f, off[0] * 255f,
            m[1][0], m[1][1], m[1][2], 0f, off[1] * 255f,
            m[2][0], m[2][1], m[2][2], 0f, off[2] * 255f,
            0f, 0f, 0f, 1f, 0f
        )
        rgbMatrix = floatArrayOf(
            m[0][0], m[1][0], m[2][0], 0f,
            m[0][1], m[1][1], m[2][1], 0f,
            m[0][2], m[1][2], m[2][2], 0f,
            off[0], off[1], off[2], 1f
        )
    }
}

object Filters {
    val all: List<FilterDef> = listOf(
        FilterDef("Normal"),
        FilterDef("Vivid", sat = 1.5f, con = 1.1f),
        FilterDef("Vivid Warm", sat = 1.4f, con = 1.1f, r = 1.08f, b = 0.92f),
        FilterDef("Vivid Cool", sat = 1.4f, con = 1.1f, r = 0.92f, b = 1.08f),
        FilterDef("Dramatic", sat = 1.1f, con = 1.4f, bri = -0.05f),
        FilterDef("Mono", sat = 0f),
        FilterDef("Noir", sat = 0f, con = 1.4f, bri = -0.05f),
        FilterDef("Silver", sat = 0f, con = 1.1f, bri = 0.05f, r = 0.98f, b = 1.03f),
        FilterDef("Sepia", sat = 0f, r = 1.07f, g = 0.74f, b = 0.43f, bri = 0.02f),
        FilterDef("Vintage", sat = 0.7f, con = 0.95f, r = 1.1f, b = 0.85f, ro = 0.03f, go = 0.02f),
        FilterDef("Retro", sat = 0.8f, r = 1.1f, g = 0.95f, b = 0.8f, bri = 0.04f),
        FilterDef("Fade", sat = 0.8f, con = 0.8f, bri = 0.08f),
        FilterDef("Matte", sat = 0.9f, con = 0.85f, bri = 0.06f, bo = 0.02f),
        FilterDef("Warm", r = 1.1f, b = 0.9f),
        FilterDef("Cool", r = 0.9f, b = 1.12f),
        FilterDef("Sunset", sat = 1.2f, r = 1.2f, g = 0.95f, b = 0.8f),
        FilterDef("Golden Hour", sat = 1.15f, r = 1.15f, g = 1.05f, b = 0.8f, bri = 0.03f),
        FilterDef("Cinematic", sat = 1.1f, con = 1.15f, r = 0.92f, g = 1.02f, b = 1.1f),
        FilterDef("Orange Teal", con = 1.2f, r = 1.1f, b = 0.92f, go = 0.02f, bo = 0.04f),
        FilterDef("Bright", bri = 0.12f, con = 1.05f),
        FilterDef("Dark", bri = -0.12f, con = 1.1f),
        FilterDef("High Contrast", con = 1.5f),
        FilterDef("Soft", con = 0.85f, sat = 0.9f, bri = 0.05f),
        FilterDef("Pastel", sat = 0.6f, con = 0.85f, bri = 0.1f),
        FilterDef("Neon", sat = 2f, con = 1.2f),
        FilterDef("Cyber", sat = 1.5f, con = 1.2f, r = 0.9f, b = 1.3f),
        FilterDef("Forest", sat = 1.2f, r = 0.9f, g = 1.1f, b = 0.9f),
        FilterDef("Ocean", r = 0.85f, b = 1.2f),
        FilterDef("Rose", r = 1.15f, g = 0.9f),
        FilterDef("Lavender", r = 1.05f, g = 0.92f, b = 1.15f),
        FilterDef("Mint", r = 0.92f, g = 1.1f),
        FilterDef("Autumn", sat = 1.2f, r = 1.15f, g = 0.95f, b = 0.75f),
        FilterDef("Winter", sat = 0.85f, r = 0.92f, b = 1.15f, bri = 0.03f),
        FilterDef("Summer", sat = 1.25f, r = 1.1f, g = 1.05f, b = 0.9f),
        FilterDef("Dream", sat = 0.8f, con = 0.85f, bri = 0.08f, r = 1.05f, b = 1.1f),
        FilterDef("Haze", sat = 0.8f, con = 0.75f, bri = 0.1f),
        FilterDef("Film", sat = 0.9f, con = 1.1f, r = 1.05f, b = 0.92f, ro = 0.02f, go = 0.01f),
        FilterDef("Kodak", sat = 1.15f, con = 1.1f, r = 1.1f, b = 0.88f),
        FilterDef("Fuji", sat = 1.1f, con = 1.08f, r = 0.95f, g = 1.05f, b = 1.05f),
        FilterDef("Polaroid", sat = 0.85f, con = 0.9f, bri = 0.05f, r = 1.08f, b = 0.9f),
        FilterDef("Lomo", sat = 1.3f, con = 1.3f, bri = -0.03f, r = 1.05f, b = 1.1f),
        FilterDef("Cross Process", con = 1.25f, r = 1.2f, g = 0.95f, b = 1.15f),
        FilterDef("Moody", sat = 0.7f, con = 1.2f, bri = -0.08f, r = 0.95f, b = 1.08f),
        FilterDef("Chrome", sat = 1.3f, con = 1.25f),
        FilterDef("Gold", sat = 0.9f, r = 1.2f, g = 1.05f, b = 0.7f),
        FilterDef("Blue Hour", bri = -0.04f, r = 0.8f, g = 0.95f, b = 1.25f),
        FilterDef("Night", con = 1.1f, bri = -0.1f, r = 0.8f, g = 0.9f, b = 1.2f),
        FilterDef("Emerald", r = 0.85f, g = 1.15f, b = 0.95f),
        FilterDef("Ruby", r = 1.25f, g = 0.85f, b = 0.9f),
        FilterDef("Peach", sat = 1.1f, bri = 0.05f, r = 1.12f, b = 0.92f),
        FilterDef("Candy", sat = 1.6f, bri = 0.06f, r = 1.08f, g = 0.95f, b = 1.1f),
        FilterDef("Sky", bri = 0.05f, r = 0.95f, g = 1.02f, b = 1.15f),
        FilterDef("Coffee", sat = 0.5f, con = 1.1f, r = 1.1f, g = 0.95f, b = 0.8f),
        FilterDef("Ice", sat = 0.6f, bri = 0.05f, r = 0.9f, g = 1.02f, b = 1.2f),
        FilterDef("Invert", con = -1f),
        FilterDef("X-Ray", sat = 0f, con = -1f),
        FilterDef("Red Tint", r = 1.3f, g = 0.8f, b = 0.8f),
        FilterDef("Green Tint", r = 0.8f, g = 1.3f, b = 0.8f),
        FilterDef("Blue Tint", r = 0.8f, g = 0.8f, b = 1.3f)
    )
}
