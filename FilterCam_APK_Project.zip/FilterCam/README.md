# 📸 FilterCam

50+ ফিল্টার সহ সিম্পল ক্যামেরা অ্যাপ (ছবি + ভিডিও)।

**Creator:** Mohammod Abdul Awal
**Student:** Department of English, National University.

## ফিচার
- 58টি ফিল্টার + Normal (ছবি ও ভিডিও দুটোতেই)
- রেশিও: 3:4, 9:16, 1:1
- রেজুলেশন: MAX / FHD / HD / SD
- ট্যাপ করে ফোকাস + আলো (Auto Exposure)
- দুই আঙুলে জুম
- Rule of Thirds গ্রিড (ডিফল্ট চালু)
- ফ্ল্যাশ (OFF/ON/AUTO), সামনে-পেছনের ক্যামেরা
- ছবি → Pictures/FilterCam, ভিডিও → Movies/FilterCam (গ্যালারিতে দেখা যাবে)

## APK বানানো (GitHub Actions)
1. GitHub-এ নতুন repository খোলো (যেমন `FilterCam`)।
2. এই ফোল্ডারের **ভিতরের সব ফাইল** (`.github` ফোল্ডার সহ) repository-র root-এ আপলোড করো।
3. **Actions** ট্যাব → **Build APK** → **Run workflow**।
4. ৩-৮ মিনিট পর সবুজ ✅ হলে ওই run খোলো → নিচে **Artifacts** → `FilterCam-APK` ডাউনলোড।
5. ZIP খুলে `app-debug.apk` ফোনে ইনস্টল করো (Unknown sources অনুমতি দিতে হবে)।

Android 10 (API 29) বা তার উপরের ফোনে চলবে।
