# ProCam Studio
Pro Camera + Photo Studio in one Android app (HTML apps inside a native WebView shell).

Creator: Mohammod Abdul Awal
Student: Department of English, National University.

## Build (GitHub Actions)
1. Upload `ProCamStudio.zip` (as-is, do not extract) to the repo root.
2. Create `.github/workflows/build.yml` (content is in this repo's zip: `.github/workflows/build.yml`).
3. Actions tab -> "Build APK" -> download `ProCam-Studio-APK` or use the Releases page.
