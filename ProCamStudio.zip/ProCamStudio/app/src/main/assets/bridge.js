/* ProCam Studio - save bridge (blob downloads -> Pictures/ProCam Studio) */
(function () {
  function B() { try { return window.AndroidBridge || (parent && parent.AndroidBridge) || null; } catch (e) { return window.AndroidBridge || null; } }
  async function saveBlob(blob, name) {
    const b = B(); if (!b) return false;
    if (!b.begin(name || 'photo.png', blob.type || 'image/png')) return false;
    const SZ = 3 * 256 * 1024; // multiple of 3 -> clean base64 chunks
    for (let i = 0; i < blob.size; i += SZ) {
      const s = await new Promise(function (r) {
        const f = new FileReader();
        f.onload = function () { r(String(f.result).split(',')[1] || ''); };
        f.readAsDataURL(blob.slice(i, i + SZ));
      });
      if (!b.chunk(s)) return false;
    }
    return b.end();
  }
  window.__saveBlob = saveBlob;
  const orig = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    if (B() && this.hasAttribute('download') && String(this.href).indexOf('blob:') === 0) {
      const a = this;
      fetch(a.href).then(function (r) { return r.blob(); })
        .then(function (bl) { return saveBlob(bl, a.getAttribute('download')); })
        .catch(function () {});
      return;
    }
    return orig.call(this);
  };
})();
